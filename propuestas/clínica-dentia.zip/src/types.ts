export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  benefits: string[];
  technology: string;
  iconName: string;
  tag?: string;
  featured?: boolean;
  bgDark?: boolean;
  imageUrl?: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  treatment: string;
  duration: string;
  tech: string;
  beforeImg: string;
  afterImg: string;
  quote: string;
  author: string;
  beforeLabel: string;
  afterLabel: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  treatment: string;
  comment: string;
  rating: number;
  date: string;
  avatarUrl: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  subtitle: string;
  price: string;
  priceNote: string;
  featured: boolean;
  badge?: string;
  features: string[];
  ctaText: string;
  financingNote?: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category?: string;
}

export interface BookingFormData {
  fullName: string;
  phone: string;
  email: string;
  service: string;
  preferredTime: string;
  notes: string;
}
