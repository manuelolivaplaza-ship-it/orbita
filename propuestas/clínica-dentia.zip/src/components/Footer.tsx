import React from 'react';
import { ToothLogo } from './ToothLogo';
import { CLINIC_INFO, SERVICES } from '../data/clinicData';
import { Phone, Mail, MapPin, Clock, ShieldCheck, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#00273d] text-white border-t border-cyan-900/40 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Col 1 & 2: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <ToothLogo lightText size={40} />
            <p className="text-cyan-100/90 text-sm max-w-sm leading-relaxed mt-4">
              Clínica odontológica líder en ortodoncia invisible, implantes guiados 3D y diseño de sonrisa en Santiago. Diagnóstico computarizado de alta precisión para tu salud oral.
            </p>

            <div className="pt-2 space-y-2 text-xs text-cyan-200">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#00BCD4] shrink-0" />
                <span>{CLINIC_INFO.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#00BCD4] shrink-0" />
                <span>{CLINIC_INFO.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#00BCD4] shrink-0" />
                <span>{CLINIC_INFO.email}</span>
              </div>
            </div>
          </div>

          {/* Col 3: Navegación */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-extrabold tracking-widest text-cyan-300">
              Navegación
            </h4>
            <ul className="space-y-2 text-sm text-cyan-100/80 font-medium">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">
                  Inicio
                </a>
              </li>
              <li>
                <a href="#especialidades" className="hover:text-white transition-colors">
                  Especialidades
                </a>
              </li>
              <li>
                <a href="#proceso" className="hover:text-white transition-colors">
                  Cómo Funciona
                </a>
              </li>
              <li>
                <a href="#casos" className="hover:text-white transition-colors">
                  Antes y Después
                </a>
              </li>
              <li>
                <a href="#testimonios" className="hover:text-white transition-colors">
                  Testimonios
                </a>
              </li>
              <li>
                <a href="#precios" className="hover:text-white transition-colors">
                  Planes y Aranceles
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Preguntas Frecuentes
                </a>
              </li>
              <li>
                <a href="#contacto" className="hover:text-white transition-colors">
                  Contacto y Ubicación
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Especialidades */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-extrabold tracking-widest text-cyan-300">
              Tratamientos
            </h4>
            <ul className="space-y-2 text-xs text-cyan-100/80 font-medium">
              {SERVICES.map((s) => (
                <li key={s.id}>
                  <a href="#especialidades" className="hover:text-white transition-colors block">
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 5: Horarios */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-extrabold tracking-widest text-cyan-300">
              Horario Clínico
            </h4>
            <div className="space-y-2 text-xs text-cyan-100/90 leading-relaxed">
              <div>
                <p className="font-bold text-white">Lunes a Viernes:</p>
                <p>09:00 a 19:00 hrs</p>
              </div>
              <div>
                <p className="font-bold text-white">Sábados:</p>
                <p>09:00 a 14:00 hrs</p>
              </div>
              <div className="pt-2 border-t border-white/10">
                <p className="text-[11px] text-cyan-300 font-semibold flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Urgencias vía WhatsApp
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar with Copyright */}
        <div className="mt-12 pt-8 border-t border-cyan-950 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-cyan-200/60">
          <p>© {currentYear} {CLINIC_INFO.name}. Todos los derechos reservados.</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Odontología Digital de Alta Precisión</span>
            <span>•</span>
            <span>Santiago, Chile</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
