import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, Sparkles, MessageSquare, Calendar } from 'lucide-react';
import { CLINIC_INFO, SERVICES } from '../data/clinicData';

interface ContactSectionProps {
  onOpenBooking: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenBooking }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    especialidad: 'ortodoncia-invisible',
    mensaje: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [ticketId, setTicketId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nombre || !formData.email) return;

    const id = 'CNT-' + Math.floor(10000 + Math.random() * 90000);
    setTicketId(id);
    setSubmitted(true);
  };

  const handleWhatsAppDirect = () => {
    const text = encodeURIComponent(
      `¡Hola Clínica Dentia! Mi nombre es ${formData.nombre || 'un paciente'} y me gustaría agendar una evaluación.`
    );
    window.open(`https://wa.me/${CLINIC_INFO.phoneClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contacto" className="py-20 lg:py-28 bg-[#003B5C] text-white relative overflow-hidden">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-96 h-96 bg-[#00BCD4]/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-96 h-96 bg-[#0077B6]/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Big Impact Closing Headline */}
        <div className="max-w-4xl mx-auto text-center mb-16">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 backdrop-blur-md text-cyan-200 font-bold text-xs rounded-full uppercase tracking-wider mb-4 border border-cyan-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            Empieza tu transformación hoy
          </span>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05] text-white">
            Tu nueva sonrisa comienza con una simple consulta digital
          </h2>
          <p className="text-base sm:text-xl text-cyan-100/90 mt-4 max-w-2xl mx-auto leading-relaxed">
            Estamos en Providencia, Santiago. Reserva tu hora en línea o escríbenos directamente.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={onOpenBooking}
              className="px-8 py-4 rounded-xl text-base sm:text-lg font-bold text-[#003B5C] bg-gradient-to-r from-cyan-300 to-[#00BCD4] hover:from-cyan-200 hover:to-cyan-400 shadow-xl shadow-cyan-500/20 hover:scale-105 transition-all flex items-center gap-2.5 cursor-pointer"
              id="btn-contact-cta-book"
            >
              <Calendar className="w-5 h-5 text-[#003B5C]" />
              <span>Agendar evaluación ahora</span>
            </button>

            <button
              onClick={handleWhatsAppDirect}
              className="px-7 py-4 rounded-xl text-base sm:text-lg font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur-md transition-all hover:scale-102 flex items-center gap-2 cursor-pointer"
              id="btn-contact-cta-whatsapp"
            >
              <MessageSquare className="w-5 h-5 text-[#00BCD4]" />
              <span>Hablar por WhatsApp</span>
            </button>
          </div>
        </div>

        {/* Contact Grid: Form + Clinical Info */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mt-12">
          
          {/* Left: Interactive Form (7 cols) */}
          <div className="lg:col-span-7 bg-white text-[#333333] rounded-2xl p-6 sm:p-10 shadow-2xl border border-gray-100">
            <div className="mb-6">
              <h3 className="text-2xl font-extrabold text-[#003B5C] tracking-tight">
                Envíanos un mensaje
              </h3>
              <p className="text-xs text-gray-700 mt-1">
                Te responderemos a la brevedad con la información de tu tratamiento.
              </p>
            </div>

            {!submitted ? (
              <form onSubmit={handleSubmit} id="contact-form" className="space-y-4">
                {/* Name */}
                <div>
                  <label htmlFor="contact-nombre" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Nombre y Apellido *
                  </label>
                  <input
                    id="contact-nombre"
                    type="text"
                    required
                    placeholder="Ej. Valentina Morales"
                    value={formData.nombre}
                    onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm outline-none transition-all"
                  />
                </div>

                {/* Email & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="contact-email" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                      Correo Electrónico *
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      required
                      placeholder="tu-correo@ejemplo.cl"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-telefono" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                      Teléfono / WhatsApp (Opcional)
                    </label>
                    <input
                      id="contact-telefono"
                      type="tel"
                      placeholder="+56 9 1234 5678"
                      value={formData.telefono}
                      onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm outline-none transition-all"
                    />
                  </div>
                </div>

                {/* Specialty */}
                <div>
                  <label htmlFor="contact-especialidad" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Tratamiento de Interés
                  </label>
                  <select
                    id="contact-especialidad"
                    value={formData.especialidad}
                    onChange={(e) => setFormData({ ...formData, especialidad: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm outline-none transition-all text-gray-800"
                  >
                    {SERVICES.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.title}
                      </option>
                    ))}
                    <option value="consulta-general">Evaluación General & Diagnóstico 3D</option>
                    <option value="urgencia">Urgencia Dental</option>
                  </select>
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="contact-mensaje" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Mensaje o Consulta Específica
                  </label>
                  <textarea
                    id="contact-mensaje"
                    rows={3}
                    placeholder="Cuéntanos brevemente tu consulta o si prefieres algún horario..."
                    value={formData.mensaje}
                    onChange={(e) => setFormData({ ...formData, mensaje: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm outline-none transition-all resize-none"
                  />
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#0077B6] to-[#0096C7] hover:from-[#005f92] hover:to-[#0077B6] text-white font-bold text-sm sm:text-base shadow-lg shadow-[#0077B6]/30 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  id="btn-submit-contact"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar Mensaje a Clínica Dentia</span>
                </button>
              </form>
            ) : (
              /* Success State in UI */
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-8 text-center space-y-4"
                id="contact-form-success"
              >
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-2xl font-extrabold text-[#003B5C]">¡Mensaje enviado con éxito!</h4>
                <p className="text-sm text-gray-600 max-w-md mx-auto">
                  Gracias por contactarnos, <strong>{formData.nombre}</strong>. Un coordinador clínico se comunicará contigo al correo <strong>{formData.email}</strong>.
                </p>
                <div className="p-3 bg-[#E8F4FB] rounded-xl border border-[#00BCD4]/30 text-xs font-mono text-[#0077B6]">
                  ID de Atención: {ticketId}
                </div>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 bg-gray-100 hover:bg-gray-200 rounded-xl text-xs font-semibold text-gray-700 transition-colors cursor-pointer"
                >
                  Enviar otra consulta
                </button>
              </motion.div>
            )}
          </div>

          {/* Right: Clinic Contact Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-4 text-white">
            
            {/* Phone / WhatsApp Card */}
            <div className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#00BCD4] text-[#003B5C] flex items-center justify-center shrink-0 shadow-md">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-cyan-300 tracking-wider">Teléfono / WhatsApp</span>
                <p className="text-xl font-bold mt-1 text-white">{CLINIC_INFO.phone}</p>
                <p className="text-xs text-cyan-100 mt-0.5">Atención telefónica y WhatsApp activo</p>
              </div>
            </div>

            {/* Email Card */}
            <div className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#0077B6] text-white flex items-center justify-center shrink-0 shadow-md">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-cyan-300 tracking-wider">Correo Electrónico</span>
                <p className="text-lg font-bold mt-1 text-white">{CLINIC_INFO.email}</p>
                <p className="text-xs text-cyan-100 mt-0.5">Presupuestos y convenios corporativos</p>
              </div>
            </div>

            {/* Address Card */}
            <div className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/20 text-cyan-300 flex items-center justify-center shrink-0 shadow-md">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-cyan-300 tracking-wider">Ubicación</span>
                <p className="text-sm font-bold mt-1 text-white">{CLINIC_INFO.address}</p>
                <p className="text-xs text-cyan-100 mt-0.5">{CLINIC_INFO.metro}</p>
              </div>
            </div>

            {/* Schedule Card */}
            <div className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/20 text-cyan-300 flex items-center justify-center shrink-0 shadow-md">
                <Clock className="w-6 h-6" />
              </div>
              <div className="space-y-1 text-xs">
                <span className="uppercase font-bold text-cyan-300 tracking-wider">Horario de Atención</span>
                <p className="text-white font-semibold">{CLINIC_INFO.hours.weekdays}</p>
                <p className="text-white/90">{CLINIC_INFO.hours.saturday}</p>
                <p className="text-cyan-200/80 text-[11px]">{CLINIC_INFO.hours.sunday}</p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
