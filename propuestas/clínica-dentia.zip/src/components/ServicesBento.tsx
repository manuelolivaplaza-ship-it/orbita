import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ShieldCheck, Activity, Smile, Heart, Zap, ArrowRight, CheckCircle2, Cpu } from 'lucide-react';
import { SERVICES } from '../data/clinicData';

interface ServicesBentoProps {
  onSelectService: (serviceId: string) => void;
}

export const ServicesBento: React.FC<ServicesBentoProps> = ({ onSelectService }) => {
  const iconMap: Record<string, React.ReactNode> = {
    Sparkles: <Sparkles className="w-6 h-6" />,
    ShieldCheck: <ShieldCheck className="w-6 h-6" />,
    Activity: <Activity className="w-6 h-6" />,
    Smile: <Smile className="w-6 h-6" />,
    Heart: <Heart className="w-6 h-6" />,
    Zap: <Zap className="w-6 h-6" />,
  };

  return (
    <section id="especialidades" className="py-20 lg:py-28 bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-[#E8F4FB] text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 border border-[#00BCD4]/30">
            Odontología Especializada & Digital
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            Especialidades diseñadas para cuidar tu salud y estética
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Combinamos experiencia clínica con software de simulación 3D y tecnología mínimamente invasiva.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {SERVICES.map((service, index) => {
            const isFeatured = service.featured;
            const isDark = service.bgDark;
            const hasImage = !!service.imageUrl;

            if (isFeatured && hasImage) {
              /* Featured Large Card with Image Overlay */
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="md:col-span-2 relative group rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between min-h-[380px] sm:min-h-[420px] p-6 sm:p-8 text-white border border-gray-100"
                  id={`service-card-${service.id}`}
                >
                  {/* Background Image & Scrim */}
                  <div className="absolute inset-0 z-0">
                    <img
                      src={service.imageUrl}
                      alt={service.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#003B5C] via-[#003B5C]/80 to-[#003B5C]/40" />
                  </div>

                  {/* Card Top */}
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00BCD4] text-[#003B5C] font-bold text-xs uppercase tracking-wider shadow-sm">
                      <Sparkles className="w-3.5 h-3.5" />
                      {service.tag || 'Destacado'}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-cyan-200">
                      {iconMap[service.iconName]}
                    </div>
                  </div>

                  {/* Card Bottom / Content */}
                  <div className="relative z-10 space-y-4 mt-8">
                    <div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                        {service.title}
                      </h3>
                      <p className="text-cyan-100/90 text-sm sm:text-base mt-2 max-w-xl leading-relaxed">
                        {service.shortDesc}
                      </p>
                    </div>

                    {/* Benefit list */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-white/15">
                      {service.benefits.map((b, bi) => (
                        <div key={bi} className="flex items-center gap-2 text-xs sm:text-sm text-cyan-50 font-medium">
                          <CheckCircle2 className="w-4 h-4 text-[#00BCD4] shrink-0" />
                          <span>{b}</span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-2 text-xs text-cyan-200">
                        <Cpu className="w-3.5 h-3.5 text-[#00BCD4]" />
                        <span>Tecnología: {service.technology}</span>
                      </div>

                      <button
                        onClick={() => onSelectService(service.id)}
                        className="px-5 py-2.5 rounded-xl bg-white text-[#003B5C] hover:bg-cyan-50 font-semibold text-xs sm:text-sm shadow-md transition-all hover:scale-105 flex items-center gap-2 cursor-pointer"
                      >
                        <span>Agendar evaluación</span>
                        <ArrowRight className="w-4 h-4 text-[#0077B6]" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            }

            if (isDark) {
              /* Solid #003B5C Dark Card */
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="bg-[#003B5C] text-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-lg hover:shadow-xl transition-all duration-300 border border-cyan-500/20 relative overflow-hidden group"
                  id={`service-card-${service.id}`}
                >
                  <div className="relative z-10 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="w-12 h-12 rounded-xl bg-[#0077B6] text-cyan-200 flex items-center justify-center shadow-md">
                        {iconMap[service.iconName]}
                      </div>
                      <span className="text-xs font-semibold text-cyan-300 bg-white/10 px-2.5 py-1 rounded-full">
                        CAD/CAM 3D
                      </span>
                    </div>

                    <div>
                      <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                        {service.title}
                      </h3>
                      <p className="text-cyan-100/90 text-sm mt-2 leading-relaxed">
                        {service.shortDesc}
                      </p>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-white/10">
                      {service.benefits.map((b, bi) => (
                        <div key={bi} className="flex items-start gap-2 text-xs text-cyan-50">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#00BCD4] mt-0.5 shrink-0" />
                          <span>{b}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="relative z-10 pt-6 mt-6 border-t border-white/10 flex items-center justify-between">
                    <span className="text-[11px] text-cyan-300/80 font-mono">
                      {service.technology}
                    </span>
                    <button
                      onClick={() => onSelectService(service.id)}
                      className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                      aria-label={`Consultar por ${service.title}`}
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              );
            }

            /* Standard Clean Light Card */
            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="bg-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 group hover:border-[#0077B6]/30"
                id={`service-card-${service.id}`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="w-12 h-12 rounded-xl bg-[#E8F4FB] text-[#0077B6] flex items-center justify-center group-hover:bg-[#0077B6] group-hover:text-white transition-colors duration-300">
                      {iconMap[service.iconName]}
                    </div>
                    {service.imageUrl && (
                      <span className="text-[11px] font-bold text-[#0077B6] bg-[#E8F4FB] px-2.5 py-0.5 rounded-full">
                        Estética Pro
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="text-xl font-bold text-[#003B5C] group-hover:text-[#0077B6] transition-colors tracking-tight">
                      {service.title}
                    </h3>
                    <p className="text-gray-700 text-sm mt-2 leading-relaxed">
                      {service.shortDesc}
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-gray-100">
                    {service.benefits.map((b, bi) => (
                      <div key={bi} className="flex items-start gap-2 text-xs text-gray-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#0077B6] mt-0.5 shrink-0" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-gray-100 flex items-center justify-between">
                  <span className="text-[11px] text-gray-500 font-medium">
                    {service.technology}
                  </span>
                  <button
                    onClick={() => onSelectService(service.id)}
                    className="flex items-center gap-1.5 text-xs font-bold text-[#0077B6] group-hover:text-[#003B5C] transition-colors cursor-pointer"
                  >
                    <span>Consultar</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
