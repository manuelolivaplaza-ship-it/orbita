import React from 'react';
import { motion } from 'motion/react';
import { Award, Users, Star, GraduationCap, Cpu, Scan, Sparkles, Eye, Shield } from 'lucide-react';
import { STATS, TECH_BADGES } from '../data/clinicData';

export const StatsBar: React.FC = () => {
  const statIcons = [Award, Users, Star, GraduationCap];

  return (
    <section id="stats" className="relative z-20 -mt-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Stats container with liquid-elevation */}
      <div className="bg-white rounded-2xl shadow-xl shadow-[#003B5C]/8 border border-gray-100 p-6 sm:p-8 lg:p-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 divide-y lg:divide-y-0 lg:divide-x divide-gray-100">
          {STATS.map((stat, index) => {
            const Icon = statIcons[index % statIcons.length];
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`flex flex-col ${index > 0 ? 'pt-6 lg:pt-0 lg:pl-6' : ''}`}
                id={`stat-card-${index}`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#E8F4FB] text-[#0077B6] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-3xl sm:text-4xl font-extrabold text-[#003B5C] tracking-tight leading-none">
                      {stat.value}
                    </span>
                  </div>
                </div>
                <h4 className="font-bold text-gray-900 text-sm sm:text-base leading-snug">
                  {stat.label}
                </h4>
                <p className="text-xs text-gray-700 mt-1 leading-relaxed">
                  {stat.detail}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Digital Tech strip banner */}
        <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-[#00BCD4]/10 text-[#0077B6]">
              <Cpu className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Equipamiento Digital Certificado:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {TECH_BADGES.map((badge) => (
              <span
                key={badge.name}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8F4FB] text-[#003B5C] text-xs font-semibold border border-[#00BCD4]/25 hover:border-[#0077B6] transition-colors"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-[#00BCD4]" />
                {badge.name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
