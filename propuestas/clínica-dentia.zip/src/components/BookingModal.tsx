import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, Clock, Sparkles, CheckCircle2, Phone, User, Mail, MessageSquare } from 'lucide-react';
import { CLINIC_INFO, SERVICES } from '../data/clinicData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  initialService = 'ortodoncia-invisible',
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    service: initialService,
    preferredDate: '',
    preferredTime: '10:00',
    notes: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone) return;

    const randomTicket = 'DNT-' + Math.floor(100000 + Math.random() * 900000);
    setTicketNumber(randomTicket);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    onClose();
  };

  const handleWhatsAppRedirect = () => {
    const selectedServiceName = SERVICES.find(s => s.id === formData.service)?.title || 'Evaluación General';
    const text = encodeURIComponent(
      `¡Hola Clínica Dentia! Me gustaría agendar una evaluación para ${selectedServiceName}. Mi nombre es ${formData.fullName || 'un paciente interesado'} y mi teléfono es ${formData.phone || ''}.`
    );
    window.open(`https://wa.me/${CLINIC_INFO.phoneClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#003B5C]/70 backdrop-blur-md"
            id="modal-backdrop"
          />

          {/* Dialog Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-100 my-8 z-10"
            id="booking-modal-dialog"
          >
            {/* Header with gradient strip */}
            <div className="bg-gradient-to-r from-[#003B5C] via-[#0077B6] to-[#00BCD4] px-6 py-5 text-white relative">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-white/10 backdrop-blur-sm">
                    <Calendar className="w-5 h-5 text-cyan-200" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-tight">Agendar Evaluación Digital</h3>
                    <p className="text-xs text-cyan-100/90 font-medium">Diagnóstico 3D y presupuesto sin compromiso</p>
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white/90 hover:text-white"
                  aria-label="Cerrar modal"
                  id="btn-close-modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 sm:p-8">
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4" id="booking-modal-form">
                  {/* Badge info */}
                  <div className="flex items-center gap-2 p-3 bg-[#E8F4FB] rounded-xl text-xs text-[#003B5C] border border-[#00BCD4]/30">
                    <Sparkles className="w-4 h-4 text-[#0077B6] shrink-0" />
                    <span>
                      <strong>Atención inmediata:</strong> Consulta de 40 min en Providencia con tecnología 3D.
                    </span>
                  </div>

                  {/* Specialty selector */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                      Especialidad o Tratamiento
                    </label>
                    <select
                      value={formData.service}
                      onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm font-medium text-gray-800 transition-all outline-none"
                      id="input-modal-service"
                    >
                      <option value="ortodoncia-invisible">Ortodoncia Invisible & Alineadores 3D</option>
                      <option value="ortodoncia-tradicional">Ortodoncia Autoligado / Brackets Zafiro</option>
                      <option value="implantes-guiados">Implantes Dentales Guiados CAD/CAM</option>
                      <option value="estetica-blanqueamiento">Estética & Blanqueamiento LED</option>
                      <option value="odontopediatria">Odontopediatría (Atención Infantil)</option>
                      <option value="endodoncia-microscopica">Endodoncia Microscópica</option>
                      <option value="evaluacion-general">Evaluación y Limpieza General</option>
                    </select>
                  </div>

                  {/* Name and Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Nombre Completo *
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          required
                          placeholder="Ej. Constanza Silva"
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm text-gray-800 outline-none transition-all"
                          id="input-modal-name"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        WhatsApp / Teléfono *
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                        <input
                          type="tel"
                          required
                          placeholder="+56 9 1234 5678"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm text-gray-800 outline-none transition-all"
                          id="input-modal-phone"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                      Correo Electrónico (Para confirmación)
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                      <input
                        type="email"
                        placeholder="tu-correo@ejemplo.cl"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm text-gray-800 outline-none transition-all"
                        id="input-modal-email"
                      />
                    </div>
                  </div>

                  {/* Schedule preferences */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Preferencia de Día
                      </label>
                      <div className="relative">
                        <Calendar className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                        <input
                          type="date"
                          value={formData.preferredDate}
                          onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm text-gray-800 outline-none transition-all"
                          id="input-modal-date"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Jornada Preferida
                      </label>
                      <div className="relative">
                        <Clock className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
                        <select
                          value={formData.preferredTime}
                          onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-[#0077B6] focus:ring-2 focus:ring-[#0077B6]/20 text-sm text-gray-800 outline-none transition-all"
                          id="input-modal-time"
                        >
                          <option value="Mañana (09:00 - 13:00)">Mañana (09:00 a 13:00)</option>
                          <option value="Tarde (14:00 - 19:00)">Tarde (14:00 a 19:00)</option>
                          <option value="Sábado (09:00 - 14:00)">Sábado por la mañana</option>
                          <option value="Urgencia - Lo antes posible">Urgencia (Lo antes posible)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 space-y-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#0077B6] to-[#0096C7] hover:from-[#005f92] hover:to-[#0077B6] text-white font-semibold text-sm sm:text-base shadow-lg shadow-[#0077B6]/30 hover:scale-[1.02] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                      id="btn-modal-submit"
                    >
                      <Sparkles className="w-4 h-4 text-cyan-200" />
                      <span>Confirmar Solicitud de Hora</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleWhatsAppRedirect}
                      className="w-full py-3 px-6 rounded-xl bg-[#E8F4FB] hover:bg-[#d0eaf8] text-[#003B5C] font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer border border-[#00BCD4]/30"
                      id="btn-modal-whatsapp"
                    >
                      <MessageSquare className="w-4 h-4 text-[#0077B6]" />
                      <span>O prefiere agendar directo por WhatsApp</span>
                    </button>
                  </div>
                </form>
              ) : (
                /* Success State */
                <div className="text-center py-6 space-y-5" id="booking-modal-success">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div>
                    <span className="inline-block px-3 py-1 bg-cyan-100 text-[#003B5C] font-bold text-xs rounded-full uppercase tracking-wider mb-2">
                      Solicitud Recibida
                    </span>
                    <h3 className="text-2xl font-bold text-[#003B5C]">¡Listo, {formData.fullName}!</h3>
                    <p className="text-gray-600 text-sm mt-2 max-w-md mx-auto">
                      Hemos reservado tu solicitud de evaluación en <strong>Clínica Dentia</strong>.
                    </p>
                  </div>

                  <div className="bg-[#E8F4FB] p-4 rounded-xl text-left border border-[#00BCD4]/30 space-y-2 text-xs text-gray-700">
                    <div className="flex justify-between border-b border-gray-200/60 pb-2">
                      <span className="text-gray-500">Código de Atención:</span>
                      <strong className="text-[#0077B6] font-mono text-sm">{ticketNumber}</strong>
                    </div>
                    <div className="flex justify-between border-b border-gray-200/60 pb-2">
                      <span className="text-gray-500">Tratamiento:</span>
                      <span className="font-semibold text-gray-800">
                        {SERVICES.find(s => s.id === formData.service)?.title || 'Evaluación 3D'}
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-gray-200/60 pb-2">
                      <span className="text-gray-500">Horario Solicitado:</span>
                      <span className="font-medium text-gray-800">{formData.preferredTime}</span>
                    </div>
                    <div className="flex justify-between pt-1">
                      <span className="text-gray-500">Ubicación:</span>
                      <span className="font-medium text-[#003B5C]">{CLINIC_INFO.address}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/60 text-xs text-amber-900 text-left">
                    💡 <em>Nota demo:</em> Nuestro equipo te enviará un mensaje al <strong>{formData.phone}</strong> para confirmar tu sillón clínico con 24h de anticipación.
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      onClick={handleWhatsAppRedirect}
                      className="flex-1 py-3 px-4 rounded-xl bg-[#25D366] hover:bg-[#1EBE5D] text-white font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Abrir WhatsApp Ahora</span>
                    </button>
                    <button
                      onClick={handleReset}
                      className="py-3 px-5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold text-sm transition-all cursor-pointer"
                    >
                      Cerrar
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
