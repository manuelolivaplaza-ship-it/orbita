import React from 'react';

interface ToothLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  lightText?: boolean;
}

export const ToothLogo: React.FC<ToothLogoProps> = ({
  className = '',
  size = 36,
  showText = true,
  lightText = false,
}) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`} id="clinic-brand-logo">
      <div
        className="relative flex items-center justify-center rounded-xl bg-gradient-to-br from-[#0077B6] via-[#0096C7] to-[#00BCD4] p-2 shadow-md shadow-[#0077B6]/25 transition-transform duration-300 hover:scale-105"
        style={{ width: size, height: size }}
      >
        {/* Stylized geometric tooth icon */}
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-white"
        >
          {/* Main tooth body with digital facet curves */}
          <path
            d="M9 7C9 4.79086 11.2386 3 14 3C15.2 3 15.7 3.6 16 4C16.3 3.6 16.8 3 18 3C20.7614 3 23 4.79086 23 7C23 10.5 22 13 22 17C22 21 21 27 18.5 29C17 30.2 16.2 27 16 23C15.8 27 15 30.2 13.5 29C11 27 10 21 10 17C10 13 9 10.5 9 7Z"
            fill="currentColor"
            fillOpacity="0.95"
          />
          {/* Sparkle / Tech precision facet */}
          <path
            d="M16 8L17.2 11.8L21 13L17.2 14.2L16 18L14.8 14.2L11 13L14.8 11.8L16 8Z"
            fill="#FFFFFF"
          />
          {/* Subtle lower light glow */}
          <circle cx="16" cy="13" r="1.5" fill="#00BCD4" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 leading-none">
            <span
              className={`font-extrabold text-xl tracking-tight transition-colors ${
                lightText ? 'text-white' : 'text-[#003B5C]'
              }`}
            >
              Clínica <span className="text-[#0077B6]">Dentia</span>
            </span>
          </div>
          <span
            className={`text-[10px] uppercase font-semibold tracking-widest mt-1 ${
              lightText ? 'text-cyan-200/80' : 'text-[#0077B6]/80'
            }`}
          >
            Odontología Digital
          </span>
        </div>
      )}
    </div>
  );
};
