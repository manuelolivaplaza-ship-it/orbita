import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Calendar, MessageSquare, ShieldCheck, ChevronDown, CheckCircle2, Play, VolumeX } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  const [videoLoaded, setVideoLoaded] = useState(false);

  const handleWhatsApp = () => {
    const text = encodeURIComponent('¡Hola Clínica Dentia! Quiero agendar una evaluación con diagnóstico 3D.');
    window.open(`https://wa.me/${CLINIC_INFO.phoneClean}?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  // Cinematic high quality dental/technology video loop
  // Reliable CDN video loops of ultra-modern clean clinic / 3d dental scan
  const videoUrl = 'https://assets.mixkit.co/videos/preview/mixkit-dentist-examining-a-patient-41617-large.mp4';
  const fallbackPoster = 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1920&auto=format&fit=crop';

  return (
    <section
      id="inicio"
      className="relative min-h-[90vh] lg:min-h-[94vh] flex items-center justify-center overflow-hidden bg-[#003B5C] text-white"
    >
      {/* Background Video / Media with subtle cinematic scrim */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video
          autoPlay
          muted
          loop
          playsInline
          poster={fallbackPoster}
          onLoadedData={() => setVideoLoaded(true)}
          className="w-full h-full object-cover object-center transform scale-105 filter brightness-[0.65] contrast-[1.1] transition-opacity duration-1000"
          id="hero-cinematic-video"
          aria-label="Video cinematográfico de clínica dental moderna"
        >
          <source src={videoUrl} type="video/mp4" />
        </video>

        {/* High-end cinematic radial and vertical gradients for absolute contrast and text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#003B5C] via-[#003B5C]/60 to-[#003B5C]/40" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#003B5C]/50 to-[#003B5C]/80" />

        {/* Tech subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.07] pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#00BCD4 1px, transparent 1px)`,
            backgroundSize: '32px 32px',
          }}
        />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 w-full">
        <div className="max-w-4xl mx-auto text-center flex flex-col items-center">
          
          {/* Trust Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-cyan-400/30 text-cyan-200 text-xs sm:text-sm font-semibold mb-6 shadow-lg shadow-black/20"
            id="hero-trust-badge"
          >
            <span className="flex text-amber-300">★ ★ ★ ★ ★</span>
            <span className="font-bold text-white">4.9 / 5.0</span>
            <span className="text-white/40">•</span>
            <span>+30 años de experiencia clínica en Santiago</span>
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-[-0.03em] leading-[0.95] sm:leading-[1.02] text-white drop-shadow-sm mb-6"
            id="hero-main-title"
          >
            Tecnología de punta para{' '}
            <span className="bg-gradient-to-r from-cyan-300 via-[#00BCD4] to-cyan-100 bg-clip-text text-transparent underline decoration-[#00BCD4]/40 decoration-wavy decoration-2 underline-offset-8">
              tu sonrisa
            </span>
          </motion.h1>

          {/* Subhead */}
          <motion.p
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="text-lg sm:text-xl md:text-2xl text-cyan-100/90 font-normal max-w-2xl mx-auto leading-relaxed mb-8 sm:mb-10 text-balance"
            id="hero-subhead"
          >
            Ortodoncia invisible, implantes guiados por computador y diseño de sonrisa 3D en Providencia. Sin dolor, con precisión digital.
          </motion.p>

          {/* Call to Actions */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto"
            id="hero-cta-group"
          >
            {/* Primary CTA */}
            <button
              onClick={onOpenBooking}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base sm:text-lg font-semibold text-white bg-gradient-to-r from-[#0077B6] to-[#0096C7] hover:from-[#005f92] hover:to-[#0077B6] border border-cyan-400/40 shadow-xl shadow-[#0077B6]/40 hover:shadow-2xl hover:shadow-[#0077B6]/60 transition-all duration-300 hover:scale-[1.04] active:scale-[0.98] flex items-center justify-center gap-3 cursor-pointer"
              id="btn-hero-primary-booking"
            >
              <Calendar className="w-5 h-5 text-cyan-200" />
              <span>Agendar evaluación</span>
            </button>

            {/* Secondary CTA Ghost */}
            <button
              onClick={handleWhatsApp}
              className="w-full sm:w-auto px-7 py-4 rounded-xl text-base sm:text-lg font-semibold text-white bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 hover:border-white/40 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2.5 cursor-pointer shadow-lg shadow-black/10"
              id="btn-hero-secondary-whatsapp"
            >
              <MessageSquare className="w-5 h-5 text-[#00BCD4]" />
              <span>Hablar por WhatsApp</span>
            </button>
          </motion.div>

          {/* Mini Highlights Pill Bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.45 }}
            className="mt-12 pt-8 border-t border-white/15 grid grid-cols-2 md:grid-cols-4 gap-4 text-left w-full max-w-3xl"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00BCD4] shrink-0" />
              <span className="text-xs text-white/90 font-medium">Escaneo 3D sin pastas</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00BCD4] shrink-0" />
              <span className="text-xs text-white/90 font-medium">Reembolso Isapres & Fonasa</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00BCD4] shrink-0" />
              <span className="text-xs text-white/90 font-medium">Hasta 24 cuotas sin interés</span>
            </div>
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#00BCD4] shrink-0" />
              <span className="text-xs text-white/90 font-medium">Atención de urgencias</span>
            </div>
          </motion.div>

        </div>
      </div>

      {/* Scroll Down Indicator */}
      <a
        href="#stats"
        aria-label="Ver estadísticas y detalles"
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 text-white/60 hover:text-white transition-colors flex flex-col items-center gap-1 group"
      >
        <span className="text-[11px] font-medium tracking-wider uppercase opacity-80 group-hover:opacity-100">Explorar</span>
        <ChevronDown className="w-4 h-4 animate-bounce text-[#00BCD4]" />
      </a>
    </section>
  );
};
