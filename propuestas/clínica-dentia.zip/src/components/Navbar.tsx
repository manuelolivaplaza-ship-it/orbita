import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Calendar, Phone, MessageSquare, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';
import { ToothLogo } from './ToothLogo';
import { CLINIC_INFO } from '../data/clinicData';

interface NavbarProps {
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock scroll when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileMenuOpen]);

  const navLinks = [
    { name: 'Inicio', href: '#inicio' },
    { name: 'Especialidades', href: '#especialidades' },
    { name: 'Cómo Funciona', href: '#proceso' },
    { name: 'Antes y Después', href: '#casos' },
    { name: 'Testimonios', href: '#testimonios' },
    { name: 'Planes', href: '#precios' },
    { name: 'Preguntas', href: '#faq' },
    { name: 'Contacto', href: '#contacto' },
  ];

  const handleLinkClick = () => {
    setMobileMenuOpen(false);
  };

  const handleWhatsAppDirect = () => {
    window.open(
      `https://wa.me/${CLINIC_INFO.phoneClean}?text=${encodeURIComponent('Hola Clínica Dentia, me gustaría consultar por disponibilidad.')}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <>
      {/* Top micro announcement banner */}
      <div className="bg-[#003B5C] text-white text-xs py-2 px-4 border-b border-cyan-500/20 font-medium select-none">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-cyan-200">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Diagnóstico 3D incluido en tu 1ª consulta</span>
            <span className="hidden sm:inline text-white/40">|</span>
            <span className="hidden sm:inline text-white/80 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#00BCD4]" /> Santiago, Providencia
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs text-white/90">
            <a
              href={`tel:${CLINIC_INFO.phoneClean}`}
              className="hover:text-cyan-200 transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3 h-3 text-[#00BCD4]" />
              <span>{CLINIC_INFO.phone}</span>
            </a>
            <span className="text-white/30 hidden sm:inline">•</span>
            <span className="text-cyan-300 hidden md:inline font-semibold">
              4.9 ★ (+8.000 pacientes)
            </span>
          </div>
        </div>
      </div>

      {/* Main sticky navigation */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/85 backdrop-blur-xl shadow-sm shadow-[#003B5C]/5 border-b border-gray-200/80 py-3'
            : 'bg-white/95 backdrop-blur-md py-4'
        }`}
        id="main-navigation"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a href="#inicio" className="focus:outline-none" aria-label="Ir al inicio de Clínica Dentia">
              <ToothLogo size={36} />
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2" aria-label="Navegación principal">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="px-3 py-1.5 rounded-lg text-sm font-semibold text-gray-700 hover:text-[#0077B6] hover:bg-[#E8F4FB] transition-all duration-150 tracking-tight"
                >
                  {link.name}
                </a>
              ))}
            </nav>

            {/* Right Action Buttons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* WhatsApp Quick Link (Desktop) */}
              <button
                onClick={handleWhatsAppDirect}
                className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-[#003B5C] bg-[#E8F4FB] hover:bg-[#d5edf8] border border-[#00BCD4]/30 transition-all duration-200 cursor-pointer"
                title="Escríbenos por WhatsApp"
                id="btn-nav-whatsapp"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#0077B6]" />
                <span className="hidden xl:inline">WhatsApp</span>
              </button>

              {/* Main Booking Button */}
              <button
                onClick={onOpenBooking}
                className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-[#0077B6] to-[#0096C7] hover:from-[#005f92] hover:to-[#0077B6] shadow-md shadow-[#0077B6]/25 hover:shadow-lg hover:shadow-[#0077B6]/35 transition-all duration-200 hover:scale-[1.03] active:scale-[0.98] cursor-pointer"
                id="btn-nav-book"
              >
                <Calendar className="w-4 h-4 text-cyan-200" />
                <span>Agendar hora</span>
              </button>

              {/* Mobile menu trigger */}
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 rounded-xl text-gray-700 hover:text-[#0077B6] hover:bg-gray-100 transition-colors"
                aria-label="Abrir menú de navegación"
                id="btn-mobile-menu-toggle"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer / Fullscreen Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex justify-end">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-[#003B5C]/60 backdrop-blur-sm"
              id="mobile-nav-backdrop"
            />

            {/* Slide-out Sheet */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="relative w-full max-w-xs sm:max-w-sm bg-white h-full shadow-2xl flex flex-col justify-between p-6 z-10 overflow-y-auto"
              id="mobile-nav-drawer"
            >
              {/* Top of drawer */}
              <div>
                <div className="flex items-center justify-between pb-6 border-b border-gray-100">
                  <ToothLogo size={32} />
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"
                    aria-label="Cerrar menú"
                    id="btn-close-mobile-menu"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                {/* Staggered Navigation Links */}
                <nav className="py-6 space-y-1" aria-label="Navegación móvil">
                  {navLinks.map((link, idx) => (
                    <motion.a
                      key={link.href}
                      href={link.href}
                      onClick={handleLinkClick}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * idx }}
                      className="block px-4 py-3 rounded-xl text-base font-semibold text-gray-800 hover:text-[#0077B6] hover:bg-[#E8F4FB] transition-colors"
                    >
                      {link.name}
                    </motion.a>
                  ))}
                </nav>
              </div>

              {/* Bottom drawer actions */}
              <div className="pt-6 border-t border-gray-100 space-y-3">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenBooking();
                  }}
                  className="w-full py-3.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#0077B6] hover:bg-[#005f92] shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Agendar evaluación</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    handleWhatsAppDirect();
                  }}
                  className="w-full py-3 px-4 rounded-xl text-sm font-semibold text-[#003B5C] bg-[#E8F4FB] border border-[#00BCD4]/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-[#0077B6]" />
                  <span>Hablar por WhatsApp</span>
                </button>

                <div className="pt-3 text-center text-xs text-gray-500">
                  <p className="font-semibold text-gray-700">{CLINIC_INFO.address}</p>
                  <p className="mt-0.5">{CLINIC_INFO.hours.weekdays}</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
