import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote, CheckCircle2, ThumbsUp } from 'lucide-react';
import { TESTIMONIALS } from '../data/clinicData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonios" className="py-20 lg:py-28 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-[#E8F4FB] text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 border border-[#00BCD4]/30">
            Opiniones Reales
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            La confianza de nuestros pacientes nos respalda
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Más de 8.000 personas han transformado su salud oral y sonrisa con nuestro equipo en Providencia.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-[#F5F7FA] rounded-2xl p-6 sm:p-8 flex flex-col justify-between border border-gray-100 hover:border-[#00BCD4]/40 hover:shadow-lg transition-all duration-300 relative group"
              id={`testimonial-card-${t.id}`}
            >
              <div>
                {/* Rating stars & date */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex text-amber-400 gap-0.5">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-xs text-gray-700 font-medium">{t.date}</span>
                </div>

                {/* Treatment badge */}
                <div className="mb-4">
                  <span className="inline-block px-2.5 py-0.5 rounded-md bg-[#E8F4FB] text-[#0077B6] font-semibold text-xs">
                    {t.treatment}
                  </span>
                </div>

                {/* Comment */}
                <p className="text-gray-700 text-sm sm:text-base leading-relaxed italic">
                  "{t.comment}"
                </p>
              </div>

              {/* Author info */}
              <div className="pt-6 mt-6 border-t border-gray-200/80 flex items-center gap-3">
                <img
                  src={t.avatarUrl}
                  alt={t.name}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border-2 border-[#00BCD4]"
                />
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-sm text-[#003B5C]">{t.name}</h3>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  </div>
                  <p className="text-xs text-gray-700 font-medium">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Aggregate Trust Bar */}
        <div className="mt-14 p-6 rounded-2xl bg-[#E8F4FB] border border-[#00BCD4]/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white text-[#0077B6] flex items-center justify-center shadow-sm">
              <ThumbsUp className="w-6 h-6" />
            </div>
            <div>
              <p className="font-bold text-[#003B5C] text-sm sm:text-base">
                98.6% de pacientes recomiendan Clínica Dentia
              </p>
              <p className="text-xs text-gray-700">
                Encuesta de satisfacción interna auditada semestralmente
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex -space-x-2 overflow-hidden">
              {TESTIMONIALS.map((t) => (
                <img
                  key={t.id}
                  src={t.avatarUrl}
                  alt={t.name}
                  referrerPolicy="no-referrer"
                  className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
                />
              ))}
            </div>
            <span className="text-xs font-bold text-[#003B5C] pl-2">
              +1.200 valoraciones
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
