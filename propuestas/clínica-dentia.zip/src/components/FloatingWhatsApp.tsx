import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Sparkles } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleOpenWhatsApp = () => {
    const defaultText = encodeURIComponent(
      '¡Hola Clínica Dentia! Quiero consultar por disponibilidad para una evaluación con escaneo 3D.'
    );
    window.open(`https://wa.me/${CLINIC_INFO.phoneClean}?text=${defaultText}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <aside
      aria-label="Atención por WhatsApp"
      className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto"
      id="floating-whatsapp-container"
    >
      {/* Interactive Tooltip Card */}
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            transition={{ duration: 0.3 }}
            className="relative bg-white text-[#003B5C] p-4 rounded-2xl shadow-xl border border-gray-100 max-w-[260px] text-xs"
            id="whatsapp-agent-tooltip"
          >
            <button
              onClick={() => setShowTooltip(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600 p-1"
              aria-label="Cerrar mensaje de ayuda"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="font-bold text-[#0077B6] uppercase tracking-wider text-[10px]">
                En línea ahora
              </span>
            </div>

            <p className="font-medium text-gray-700 leading-snug">
              ¿Dudas con tu tratamiento o quieres agendar para hoy? Escríbenos por WhatsApp.
            </p>

            <div className="mt-2.5 pt-2 border-t border-gray-100 flex items-center justify-between text-[11px] text-[#0077B6] font-semibold">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#00BCD4]" /> Respuesta inmediata
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={handleOpenWhatsApp}
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] text-white shadow-xl shadow-[#25D366]/35 hover:shadow-2xl hover:shadow-[#25D366]/50 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-[#25D366]/40 cursor-pointer"
        aria-label="Hablar por WhatsApp con Clínica Dentia"
        id="btn-floating-whatsapp"
      >
        {/* Subtle pulsating ring */}
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-25 pointer-events-none" />

        {/* WhatsApp Icon */}
        <MessageCircle className="w-7 h-7 fill-white/10 text-white transition-transform group-hover:scale-110" />
      </motion.button>
    </aside>
  );
};
