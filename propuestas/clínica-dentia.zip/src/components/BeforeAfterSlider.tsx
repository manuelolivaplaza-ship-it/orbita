import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, MoveHorizontal, CheckCircle2, Clock, Cpu, Award, ArrowRight } from 'lucide-react';
import { BEFORE_AFTER_CASES } from '../data/clinicData';

interface BeforeAfterSliderProps {
  onOpenBooking: () => void;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ onOpenBooking }) => {
  const [activeCaseIndex, setActiveCaseIndex] = useState(0);
  const [sliderPosition, setSliderPosition] = useState(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentCase = BEFORE_AFTER_CASES[activeCaseIndex];

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    let percentage = (x / rect.width) * 100;
    if (percentage < 5) percentage = 5;
    if (percentage > 95) percentage = 95;
    setSliderPosition(percentage);
  }, []);

  const handleMouseDown = () => setIsDragging(true);
  const handleMouseUp = () => setIsDragging(false);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      handleMove(e.clientX);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches[0]) {
      handleMove(e.touches[0].clientX);
    }
  };

  return (
    <section id="casos" className="py-20 lg:py-28 bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <span className="inline-block px-3 py-1 bg-[#E8F4FB] text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 border border-[#00BCD4]/30">
            Resultados Clínicos Reales
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            Casos de Antes y Después con tecnología digital
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Desliza el control interactivo para comparar la evolución estética y funcional de nuestros pacientes.
          </p>
        </div>

        {/* Case Switcher Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-10">
          {BEFORE_AFTER_CASES.map((c, idx) => (
            <button
              key={c.id}
              onClick={() => {
                setActiveCaseIndex(idx);
                setSliderPosition(50);
              }}
              className={`px-4 sm:px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm transition-all duration-200 cursor-pointer ${
                activeCaseIndex === idx
                  ? 'bg-[#0077B6] text-white shadow-md shadow-[#0077B6]/30 scale-105'
                  : 'bg-white text-gray-700 hover:bg-[#E8F4FB] hover:text-[#0077B6] border border-gray-200'
              }`}
              id={`tab-case-${c.id}`}
            >
              {c.treatment}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Card */}
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left: Interactive Image Slider (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center bg-gray-900 text-white relative select-none">
            <div
              ref={containerRef}
              onMouseDown={handleMouseDown}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onMouseMove={handleMouseMove}
              onTouchMove={handleTouchMove}
              className="relative w-full aspect-[4/3] rounded-xl overflow-hidden cursor-ew-resize select-none touch-none shadow-2xl"
              id="before-after-image-container"
            >
              {/* AFTER Image (Full background) */}
              <img
                src={currentCase.afterImg}
                alt="Resultado Después del tratamiento"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              />
              <div className="absolute top-4 right-4 z-10 px-3 py-1 bg-[#00BCD4]/90 backdrop-blur-md rounded-full text-xs font-bold text-[#003B5C] shadow-md uppercase tracking-wider">
                {currentCase.afterLabel}
              </div>

              {/* BEFORE Image (Clipped overlay) */}
              <div
                className="absolute inset-0 overflow-hidden pointer-events-none"
                style={{ clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)` }}
              >
                <img
                  src={currentCase.beforeImg}
                  alt="Condición Antes del tratamiento"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 z-10 px-3 py-1 bg-black/70 backdrop-blur-md rounded-full text-xs font-bold text-white shadow-md uppercase tracking-wider">
                  {currentCase.beforeLabel}
                </div>
              </div>

              {/* Dividing Slider Line & Handle */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_12px_rgba(0,0,0,0.6)] cursor-ew-resize z-20"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white text-[#003B5C] shadow-2xl flex items-center justify-center border-2 border-[#00BCD4]">
                  <MoveHorizontal className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Instruction helper */}
            <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#00BCD4]" />
                Arrastra la barra para comparar
              </span>
              <span>100% Casos Clínicos Propios</span>
            </div>
          </div>

          {/* Right: Case Details and Patient Quote (5 cols) */}
          <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E8F4FB] text-[#0077B6] text-xs font-bold uppercase tracking-wider">
                <Award className="w-3.5 h-3.5" />
                {currentCase.treatment}
              </div>

              <h3 className="text-2xl font-extrabold text-[#003B5C] leading-tight">
                {currentCase.title}
              </h3>

              {/* Case Stats */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                    <Clock className="w-3.5 h-3.5 text-[#0077B6]" />
                    <span>Duración:</span>
                  </div>
                  <p className="font-bold text-sm text-[#003B5C]">{currentCase.duration}</p>
                </div>

                <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1">
                    <Cpu className="w-3.5 h-3.5 text-[#0077B6]" />
                    <span>Tecnología:</span>
                  </div>
                  <p className="font-bold text-xs text-[#003B5C] leading-tight">{currentCase.tech}</p>
                </div>
              </div>

              {/* Patient Testimonial Quote */}
              <div className="p-4 rounded-xl bg-[#E8F4FB]/50 border-l-4 border-[#0077B6] space-y-2 mt-4">
                <p className="italic text-gray-700 text-sm leading-relaxed">
                  "{currentCase.quote}"
                </p>
                <p className="text-xs font-bold text-[#003B5C]">
                  — {currentCase.author}
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-gray-100">
              <button
                onClick={onOpenBooking}
                className="w-full py-3.5 px-6 rounded-xl bg-[#0077B6] hover:bg-[#005f92] text-white font-semibold text-sm shadow-md shadow-[#0077B6]/20 transition-all hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
                id="btn-case-book"
              >
                <span>Quiero un resultado como este</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
