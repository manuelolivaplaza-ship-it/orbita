import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle, MessageSquare, Phone } from 'lucide-react';
import { FAQ_ITEMS, CLINIC_INFO } from '../data/clinicData';

export const FaqSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('faq-1');

  const toggleItem = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const handleWhatsAppHelp = () => {
    window.open(
      `https://wa.me/${CLINIC_INFO.phoneClean}?text=${encodeURIComponent('Hola Clínica Dentia, tengo una duda antes de agendar mi hora.')}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-3 py-1 bg-[#E8F4FB] text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 border border-[#00BCD4]/30">
            Resolvemos tus Dudas
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            Preguntas Frecuentes
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Todo lo que necesitas saber antes de tu primera consulta en Clínica Dentia.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4" id="faq-accordion-group">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openId === item.id;

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#E8F4FB]/50 border-[#00BCD4]/40 shadow-sm'
                    : 'bg-white border-gray-200 hover:border-gray-300'
                }`}
              >
                <button
                  onClick={() => toggleItem(item.id)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left gap-4 cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                  id={`faq-btn-${item.id}`}
                >
                  <span className="font-bold text-base sm:text-lg text-[#003B5C] leading-snug">
                    {item.question}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-[#0077B6] text-white' : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <div className="px-6 pb-6 pt-1 text-sm sm:text-base text-gray-700 leading-relaxed border-t border-gray-100">
                        {item.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        {/* Still have questions prompt */}
        <div className="mt-12 text-center p-6 bg-[#F5F7FA] rounded-2xl border border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <p className="font-bold text-[#003B5C] text-sm sm:text-base">
              ¿Tienes otra pregunta sobre tu caso específico?
            </p>
            <p className="text-xs text-gray-700 mt-0.5">
              Nuestro equipo responde directamente por WhatsApp en minutos.
            </p>
          </div>

          <button
            onClick={handleWhatsAppHelp}
            className="px-5 py-2.5 rounded-xl bg-[#0077B6] hover:bg-[#005f92] text-white font-semibold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
            id="btn-faq-whatsapp-help"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Consultar por WhatsApp</span>
          </button>
        </div>

      </div>
    </section>
  );
};
