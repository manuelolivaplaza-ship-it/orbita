import React from 'react';
import { motion } from 'motion/react';
import { Check, Sparkles, Shield, CreditCard, ArrowRight } from 'lucide-react';
import { PRICING_PLANS } from '../data/clinicData';

interface PricingSectionProps {
  onSelectPlan: (planId: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  return (
    <section id="precios" className="py-20 lg:py-28 bg-[#F5F7FA] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-[#E8F4FB] text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 border border-[#00BCD4]/30">
            Transparencia & Presupuesto Claro
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            Planes y aranceles con financiamiento a tu alcance
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Sin costos sorpresas. Valores claros con opción de pago en cuotas y reembolso con Isapres o seguros.
          </p>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRICING_PLANS.map((plan, idx) => {
            const isFeatured = plan.featured;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className={`relative rounded-2xl flex flex-col justify-between p-8 transition-all duration-300 ${
                  isFeatured
                    ? 'bg-gradient-to-b from-[#003B5C] to-[#00273d] text-white shadow-2xl scale-105 border-2 border-[#00BCD4] z-10'
                    : 'bg-white text-gray-900 shadow-md hover:shadow-xl border border-gray-100'
                }`}
                id={`pricing-card-${plan.id}`}
              >
                {/* Featured Badge */}
                {isFeatured && plan.badge && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#00BCD4] to-[#0077B6] text-[#003B5C] font-extrabold text-xs tracking-wider uppercase shadow-md flex items-center gap-1.5 whitespace-nowrap">
                    <Sparkles className="w-3.5 h-3.5 text-[#003B5C]" />
                    {plan.badge}
                  </div>
                )}

                <div>
                  {/* Plan Name & Subtitle */}
                  <div className="mb-6">
                    <h3 className={`text-2xl font-extrabold tracking-tight ${isFeatured ? 'text-white' : 'text-[#003B5C]'}`}>
                      {plan.name}
                    </h3>
                    <p className={`text-xs mt-2 leading-relaxed ${isFeatured ? 'text-cyan-100' : 'text-gray-700'}`}>
                      {plan.subtitle}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="mb-6 pb-6 border-b border-gray-200/20">
                    <div className="flex items-baseline gap-1">
                      <span className={`text-4xl sm:text-5xl font-extrabold tracking-tight ${isFeatured ? 'text-white' : 'text-[#003B5C]'}`}>
                        {plan.price}
                      </span>
                    </div>
                    <p className={`text-xs mt-1 font-medium ${isFeatured ? 'text-cyan-200' : 'text-gray-700'}`}>
                      {plan.priceNote}
                    </p>
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 mb-8">
                    <p className={`text-xs font-bold uppercase tracking-wider ${isFeatured ? 'text-cyan-200' : 'text-gray-700'}`}>
                      Incluye:
                    </p>
                    {plan.features.map((feat, fi) => (
                      <div key={fi} className="flex items-start gap-2.5 text-xs sm:text-sm">
                        <div className={`p-0.5 rounded-full mt-0.5 shrink-0 ${isFeatured ? 'bg-cyan-400/20 text-[#00BCD4]' : 'bg-[#E8F4FB] text-[#0077B6]'}`}>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                        <span className={isFeatured ? 'text-cyan-50' : 'text-gray-700'}>
                          {feat}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Plan Footer & CTA */}
                <div className="space-y-3 pt-4 border-t border-gray-200/20">
                  <button
                    onClick={() => onSelectPlan(plan.id)}
                    className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm shadow-md transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 cursor-pointer ${
                      isFeatured
                        ? 'bg-gradient-to-r from-[#00BCD4] to-[#0096C7] hover:from-[#00a2b8] hover:to-[#0077B6] text-[#003B5C] font-extrabold shadow-cyan-500/20'
                        : 'bg-[#0077B6] hover:bg-[#005f92] text-white shadow-[#0077B6]/20'
                    }`}
                    id={`btn-plan-${plan.id}`}
                  >
                    <span>{plan.ctaText}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  {plan.financingNote && (
                    <div className="flex items-center justify-center gap-1.5 text-[11px] text-center font-medium opacity-80">
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>{plan.financingNote}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Payment and Insurance badges */}
        <div className="mt-12 p-4 bg-white rounded-xl border border-gray-200 text-center text-xs text-gray-700 flex flex-wrap items-center justify-center gap-6">
          <span className="font-semibold text-gray-700">Medios de pago aceptados:</span>
          <span>💳 Tarjetas de Crédito / Débito (Webpay)</span>
          <span>🏦 Transferencia Bancaria</span>
          <span>📄 Emisión de boleta para reembolso en Isapres y Seguros</span>
          <span>⚡ Hasta 24 cuotas sin interés según banco</span>
        </div>

      </div>
    </section>
  );
};
