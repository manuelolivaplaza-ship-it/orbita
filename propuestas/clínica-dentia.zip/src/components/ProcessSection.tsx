import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, Calendar, CheckCircle2, ArrowRight, Sparkles, Shield, Clock } from 'lucide-react';
import { PROCESS_STEPS } from '../data/clinicData';

interface ProcessSectionProps {
  onOpenBooking: () => void;
}

export const ProcessSection: React.FC<ProcessSectionProps> = ({ onOpenBooking }) => {
  const iconMap: Record<string, React.ReactNode> = {
    MessageSquare: <MessageSquare className="w-6 h-6" />,
    Calendar: <Calendar className="w-6 h-6" />,
    CheckCircle2: <CheckCircle2 className="w-6 h-6" />,
  };

  return (
    <section id="proceso" className="py-20 lg:py-28 bg-[#E8F4FB]/60 relative overflow-hidden">
      {/* Decorative background grid */}
      <div
        className="absolute inset-0 opacity-40 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#0077B6 0.75px, transparent 0.75px)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block px-3 py-1 bg-white text-[#0077B6] font-bold text-xs rounded-full uppercase tracking-wider mb-3 shadow-sm border border-[#00BCD4]/30">
            Paso a Paso Transparente
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#003B5C] tracking-tight leading-tight">
            Cómo funciona tu atención en Clínica Dentia
          </h2>
          <p className="text-base sm:text-lg text-gray-700 mt-4 leading-relaxed">
            Sin burocracia, sin esperas interminables y con total claridad sobre tus opciones clínicas.
          </p>
        </div>

        {/* 3 Steps Timeline / Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {PROCESS_STEPS.map((step, idx) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.15 }}
              className="relative bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col justify-between"
              id={`process-step-${idx}`}
            >
              {/* Step indicator badge & number */}
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-[#E8F4FB] text-[#0077B6] flex items-center justify-center shadow-inner">
                  {iconMap[step.icon]}
                </div>
                <span className="text-4xl font-extrabold text-[#00BCD4]/40 font-mono tracking-tighter">
                  {step.step}
                </span>
              </div>

              {/* Step Content */}
              <div className="space-y-3">
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#E8F4FB] text-[#0077B6] text-[11px] font-bold uppercase tracking-wider">
                  {step.highlight}
                </span>
                <h3 className="text-xl font-bold text-[#003B5C] leading-snug">
                  {step.title}
                </h3>
                <p className="text-gray-700 text-sm leading-relaxed">
                  {step.desc}
                </p>
              </div>

              {/* Step Footer info */}
              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center gap-2 text-xs font-semibold text-gray-500">
                <Clock className="w-3.5 h-3.5 text-[#00BCD4]" />
                <span>
                  {idx === 0 && 'Tiempo estimado: 2 minutos'}
                  {idx === 1 && 'Confirmación en el acto'}
                  {idx === 2 && 'Presupuesto 100% claro'}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Action Callout inside Process */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-12 bg-gradient-to-r from-[#003B5C] via-[#0077B6] to-[#0096C7] rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6"
          id="process-callout-banner"
        >
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              ¿Listo para empezar tu cambio de sonrisa?
            </h4>
            <p className="text-sm text-cyan-100/90 max-w-xl">
              Agenda hoy tu evaluación 3D y descubre el resultado antes de comenzar.
            </p>
          </div>

          <button
            onClick={onOpenBooking}
            className="px-6 py-3.5 rounded-xl bg-white text-[#003B5C] hover:bg-cyan-50 font-bold text-sm shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
            id="btn-process-action"
          >
            <span>Agendar mi hora ahora</span>
            <ArrowRight className="w-4 h-4 text-[#0077B6]" />
          </button>
        </motion.div>

      </div>
    </section>
  );
};
