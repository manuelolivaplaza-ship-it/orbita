import { ServiceItem, CaseStudy, Testimonial, PricingPlan, FaqItem } from '../types';

export const CLINIC_INFO = {
  name: 'Clínica Dentia',
  tagline: 'Tecnología de punta para tu sonrisa',
  phone: '+56 9 8765 4321',
  phoneClean: '56987654321',
  email: 'hola@clinicadentia.cl',
  address: 'Av. Providencia 1234, Of. 601, Santiago, Chile',
  city: 'Santiago, Chile',
  metro: 'A pasos de Metro Manuel Montt / Los Leones',
  hours: {
    weekdays: 'Lunes a Viernes: 9:00 – 19:00 hrs',
    saturday: 'Sábados: 9:00 – 14:00 hrs',
    sunday: 'Domingos y festivos: Cerrado (Urgencias activas por WhatsApp)',
  },
  rating: 4.9,
  reviewsCount: '+8.000',
  yearsExp: '+30',
  specialtiesCount: '+10',
};

export const STATS = [
  {
    value: '+30',
    unit: 'Años',
    label: 'De trayectoria clínica',
    detail: 'Innovando en odontología digital desde 1996 en Santiago',
  },
  {
    value: '+8.000',
    unit: 'Pacientes',
    label: 'Sonrisas transformadas',
    detail: 'Adultos y adolescentes con tratamientos exitosos',
  },
  {
    value: '4.9',
    unit: '★ Rating',
    label: 'Satisfacción promedio',
    detail: 'Basado en más de 1.200 valoraciones verificadas',
  },
  {
    value: '+10',
    unit: 'Especialidades',
    label: 'Equipo multidisciplinario',
    detail: 'Especialistas certificados con postgrado universitario',
  },
];

export const TECH_BADGES = [
  { name: 'Escáner Intraoral 3D HD', icon: 'Cpu' },
  { name: 'Tomografía Cone Beam 3D', icon: 'Scan' },
  { name: 'Software Simulación SmileDesign', icon: 'Sparkles' },
  { name: 'Microscopía Endodóntica', icon: 'Eye' },
  { name: 'Sedación Consciente Segura', icon: 'HeartPulse' },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'ortodoncia-invisible',
    title: 'Ortodoncia Invisible & Alineadores',
    shortDesc: 'Alinea tus dientes sin brackets metálicos con placas transparentes ultradelgadas y removibles.',
    benefits: [
      '100% invisibles y cómodos para hablar y comer',
      'Planificación 3D digital con vista del resultado final',
      'Menos citas presenciales y cambios cada 10 a 14 días',
    ],
    technology: 'Escaneo 3D iTero + Software ClinCheck',
    iconName: 'Sparkles',
    tag: 'Tratamiento Estrella',
    featured: true,
    imageUrl: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=1200&auto=format&fit=crop',
  },
  {
    id: 'ortodoncia-tradicional',
    title: 'Ortodoncia Avanzada & Autoligado',
    shortDesc: 'Corrección de mordida y alineación con brackets estéticos de zafiro o metálicos de baja fricción.',
    benefits: [
      'Fuerzas suaves y menor tiempo total de tratamiento',
      'Opción zafiro 100% translúcido que no se mancha',
      'Indicado para casos de alta complejidad oclusal',
    ],
    technology: 'Arcos termoactivos de memoria de forma',
    iconName: 'ShieldCheck',
    featured: false,
  },
  {
    id: 'implantes-guiados',
    title: 'Implantes Dentales Guiados por Computador',
    shortDesc: 'Recupera tus piezas dentales perdidas con titanio biocompatible de grado médico y coronas de zirconio.',
    benefits: [
      'Cirugía guiada 3D mínimamente invasiva',
      'Sin incisiones extensas ni suturas molestas',
      'Integración ósea rápida y resultados naturales de por vida',
    ],
    technology: 'Guías quirúrgicas CAD/CAM 3D',
    iconName: 'Activity',
    featured: false,
    bgDark: true,
  },
  {
    id: 'estetica-blanqueamiento',
    title: 'Estética Dental & Blanqueamiento LED',
    shortDesc: 'Diseño de sonrisa armónico con aclaramiento profesional y carillas cerámicas de mínima invasión.',
    benefits: [
      'Hasta 6 tonos más blancos en una sola sesión de 45 min',
      'Fórmulas con desensibilizantes activos de alta seguridad',
      'Carillas ultrafinas sin desgastar tu esmalte sano',
    ],
    technology: 'Lámpara LED Cold-Light + Carillas E-Max',
    iconName: 'Smile',
    featured: false,
    imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=1200&auto=format&fit=crop',
  },
  {
    id: 'odontopediatria',
    title: 'Odontopediatría & Atención Familiar',
    shortDesc: 'Cuidado preventivo y corrección temprana para niños y adolescentes en un entorno cálido y sin miedo.',
    benefits: [
      'Enfoque sin dolor y técnicas de manejo conductual',
      'Sellantes de fisuras y fluoración de alta concentración',
      'Ortopedia maxilar temprana para guiar el crecimiento óseo',
    ],
    technology: 'Odontología amigable & Cámara intraoral',
    iconName: 'Heart',
    featured: false,
  },
  {
    id: 'endodoncia-microscopica',
    title: 'Endodoncia Microscópica',
    shortDesc: 'Salva tus dientes naturales con tratamiento de conducto de alta precisión guiado por microscopio.',
    benefits: [
      'Resolución en 1 sola sesión en la mayoría de los casos',
      'Anestesia digital computarizada sin dolor',
      'Limpieza tridimensional de conductos con ultrasonido',
    ],
    technology: 'Microscopio Quirúrgico Carl Zeiss',
    iconName: 'Zap',
    featured: false,
  },
];

export const PROCESS_STEPS = [
  {
    step: '01',
    title: 'Escríbenos por WhatsApp o formulario',
    desc: 'Coordina tu cita en menos de 2 minutos. Nuestro equipo de orientación clínica te responderá al instante.',
    icon: 'MessageSquare',
    highlight: 'Respuesta inmediata',
  },
  {
    step: '02',
    title: 'Elige especialidad y tu horario ideal',
    desc: 'Contamos con agenda flexible de lunes a sábado en pleno corazón de Providencia con estacionamiento.',
    icon: 'Calendar',
    highlight: 'Sin listas de espera',
  },
  {
    step: '03',
    title: 'Evaluación digital y plan a tu medida',
    desc: 'Realizamos escaneo 3D, fotografías diagnósticas y te entregamos un presupuesto claro con simulación previa.',
    icon: 'CheckCircle2',
    highlight: 'Diagnóstico 3D incluido',
  },
];

export const BEFORE_AFTER_CASES: CaseStudy[] = [
  {
    id: 'case-aligners',
    title: 'Caso Ortodoncia Invisible (Alineadores 3D)',
    treatment: 'Alineadores Invisibles DentiaFlex',
    duration: '8 meses de tratamiento',
    tech: 'Escáner 3D iTero + Simulación ClinCheck',
    beforeImg: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?q=80&w=1200&auto=format&fit=crop',
    afterImg: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=1200&auto=format&fit=crop',
    quote: 'Tenía miedo de usar brackets a mis 29 años. Con los alineadores nadie notó que estaba en tratamiento y en 8 meses mi mordida cambió por completo.',
    author: 'Camila P. (29 años, Santiago)',
    beforeLabel: 'Antes (Apiñamiento moderado)',
    afterLabel: 'Después (Alineación y arco armónico)',
  },
  {
    id: 'case-whitening',
    title: 'Caso Blanqueamiento LED + Microestética',
    treatment: 'Aclaramiento Láser & Recontorneo',
    duration: '2 sesiones clínicas',
    tech: 'Lámpara LED ColdLight + Resina Biomimética',
    beforeImg: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1200&auto=format&fit=crop',
    afterImg: 'https://images.unsplash.com/photo-1571772996211-2f02c9727629?q=80&w=1200&auto=format&fit=crop',
    quote: 'El cambio de tono fue inmediato sin nada de sensibilidad molesta. Me siento mucho más segura sonriendo en reuniones y fotos.',
    author: 'Ana M. (34 años, Santiago)',
    beforeLabel: 'Antes (Pigmentación por café y tabaco)',
    afterLabel: 'Después (6 tonos más blanco y bordes pulidos)',
  },
  {
    id: 'case-implants',
    title: 'Caso Implante Unitario Guiado 3D',
    treatment: 'Implante Titanio Grado 5 + Corona Zirconio',
    duration: 'Cirugía en 30 minutos',
    tech: 'Tomografía Cone Beam 3D + Guía CAD/CAM',
    beforeImg: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1200&auto=format&fit=crop',
    afterImg: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=1200&auto=format&fit=crop',
    quote: 'Pensé que el implante iba a doler, pero con la guía computarizada no sentí nada. Al día siguiente pude comer con normalidad.',
    author: 'Luis R. (45 años, Santiago)',
    beforeLabel: 'Antes (Ausencia de pieza premolar)',
    afterLabel: 'Después (Rehabilitación anatómica fija)',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    name: 'Ana M.',
    role: 'Paciente hace 3 años',
    treatment: 'Blanqueamiento LED & Limpieza Ultrasónica',
    comment: 'La puntualidad y la tecnología de la clínica son impresionantes. Me mostraron fotos en alta definición de mis dientes antes de empezar y me explicaron cada detalle con mucha calma. Cero dolor.',
    rating: 5,
    date: 'Hace 2 semanas',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop',
  },
  {
    id: 't-2',
    name: 'Luis R.',
    role: 'Paciente implante guiado',
    treatment: 'Cirugía 3D & Corona en Zirconio',
    comment: 'Llegué con mucho recelo por malas experiencias previas en otros centros. En Dentia la cirugía con guía computarizada duró media hora y la recuperación fue excelente. Muy profesionales.',
    rating: 5,
    date: 'Hace 1 mes',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
  },
  {
    id: 't-3',
    name: 'Camila P.',
    role: 'Paciente ortodoncia invisible',
    treatment: 'Alineadores Transparentes DentiaFlex',
    comment: 'Terminé mis alineadores el mes pasado. Poder sacármelos para eventos y comidas fue lo mejor. El seguimiento con la app y los escaneos 3D me dieron total tranquilidad durante el proceso.',
    rating: 5,
    date: 'Hace 3 semanas',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
  },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'eval-inicial',
    name: 'Evaluación Inicial Digital',
    subtitle: 'Diagnóstico 3D completo y plan de tratamiento personalizado',
    price: '$19.990',
    priceNote: 'Valor referencial de demo (Deducible si inicias tratamiento)',
    featured: false,
    features: [
      'Escaneo Intraoral 3D de alta definición',
      'Set de fotografías clínicas diagnósticas',
      'Revisión oclusal y de salud periodontal',
      'Simulación digital de resultados en pantalla',
      'Presupuesto detallado sin costos ocultos',
    ],
    ctaText: 'Agendar mi evaluación',
    financingNote: 'Atención con Fonasa e Isapres vía reembolso',
  },
  {
    id: 'plan-preventivo',
    name: 'Plan Preventivo Anual',
    subtitle: 'El cuidado continuo más recomendado por nuestros especialistas',
    price: '$89.990',
    priceNote: 'Valor anual o 12 cuotas de $7.490 s/interés',
    featured: true,
    badge: 'MÁS ELEGIDO POR FAMILIAS',
    features: [
      '2 limpiezas profundas con ultrasonido al año',
      '2 aplicaciones de flúor barniz remineralizante',
      'Radiografías bitewing de control incluidas',
      '10% descuento en cualquier otro tratamiento',
      'Atención prioritaria para urgencias dentales',
    ],
    ctaText: 'Contratar plan preventivo',
    financingNote: 'Hasta 12 cuotas sin interés con todas las tarjetas',
  },
  {
    id: 'plan-ortodoncia',
    name: 'Plan Ortodoncia & Alineadores',
    subtitle: 'Tratamiento integral con tecnología digital de inicio a fin',
    price: 'Desde $49.990',
    priceNote: 'Cuota mensual financiada según evaluación previa',
    featured: false,
    features: [
      'Estudio cefalométrico y simulación 3D ClinCheck',
      'Set completo de alineadores o brackets estéticos',
      'Controles clínicos mensuales con especialista',
      'Kit de higiene y estuche magnético premium',
      'Retenedores post-tratamiento de alta durabilidad',
    ],
    ctaText: 'Evaluar mi ortodoncia',
    financingNote: 'Financiamiento directo hasta 24 cuotas sin interés',
  },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    question: '¿Atienden por Fonasa o Isapre?',
    answer: 'Sí. Emitimos boletas electrónicas detalladas con los códigos arancelarios oficiales del Colegio de Dentistas para que puedas tramitar el reembolso directo en tu Isapre o seguro complementario de salud. Además, contamos con convenios con las principales aseguradoras.',
    category: 'Coberturas',
  },
  {
    id: 'faq-2',
    question: '¿Qué convenios con empresas y seguros tienen disponibles?',
    answer: 'Mantenemos convenios corporativos con instituciones educativas, empresas y cajas de compensación, otorgando entre un 15% y 25% de arancel preferencial para el paciente titular y sus cargas familiares directas.',
    category: 'Convenios',
  },
  {
    id: 'faq-3',
    question: '¿Atienden urgencias dentales en el mismo día?',
    answer: 'Sí, reservamos bloques diarios de atención prioritaria para urgencias por dolor agudo, fracturas dentales o caídas de piezas. Escríbenos directamente por WhatsApp para coordinar tu ingreso de inmediato.',
    category: 'Atención',
  },
  {
    id: 'faq-4',
    question: '¿Cuáles son los medios de pago y opciones de cuotas?',
    answer: 'Aceptamos tarjetas de débito, crédito (Webpay, Transbank), transferencias bancarias y efectivo. Puedes pagar todos los tratamientos en 3, 6, 12 y hasta 24 cuotas sin interés según tu banco emisor.',
    category: 'Pagos',
  },
  {
    id: 'faq-5',
    question: '¿Cómo funciona la primera cita de evaluación?',
    answer: 'En tu primera consulta de 40 minutos te realizamos un escaneo intraoral 3D (sin pastas incómodas), evaluamos encías y piezas dentales, y te mostramos en pantalla la proyección de tu sonrisa junto al presupuesto transparente.',
    category: 'Procedimientos',
  },
  {
    id: 'faq-6',
    question: '¿Dónde están ubicados y qué facilidades de acceso tienen?',
    answer: 'Nuestra clínica está ubicada en Av. Providencia 1234, Oficina 601, Santiago (a solo 2 cuadras de Metro Manuel Montt). Contamos con estacionamiento cubierto para pacientes y acceso universal para personas con movilidad reducida.',
    category: 'Ubicación',
  },
];
