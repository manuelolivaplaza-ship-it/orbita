import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { StatsBar } from './components/StatsBar';
import { ServicesBento } from './components/ServicesBento';
import { ProcessSection } from './components/ProcessSection';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedService, setSelectedService] = useState('ortodoncia-invisible');

  const handleOpenBooking = (serviceId?: string) => {
    if (serviceId) {
      setSelectedService(serviceId);
    }
    setIsBookingOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] text-[#333333] font-sans antialiased selection:bg-[#00BCD4]/20 selection:text-[#003B5C]">
      {/* Navigation */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* Main Content Sections */}
      <main id="main-content">
        {/* Hero Section */}
        <Hero onOpenBooking={() => handleOpenBooking()} />

        {/* Section A: Trust / Stats Bar */}
        <StatsBar />

        {/* Section B: Services Bento Grid */}
        <ServicesBento onSelectService={(serviceId) => handleOpenBooking(serviceId)} />

        {/* Section C: How it works / Process */}
        <ProcessSection onOpenBooking={() => handleOpenBooking()} />

        {/* Section D: Before and After Interactive Case Studies */}
        <BeforeAfterSlider onOpenBooking={() => handleOpenBooking()} />

        {/* Section E: Testimonials */}
        <TestimonialsSection />

        {/* Section F: Pricing Plans */}
        <PricingSection onSelectPlan={(planId) => handleOpenBooking(planId)} />

        {/* Section G: Frequently Asked Questions */}
        <FaqSection />

        {/* Section H: Closing CTA + Contact Form */}
        <ContactSection onOpenBooking={() => handleOpenBooking()} />
      </main>

      {/* Section I: Footer */}
      <Footer />

      {/* Booking Dialog Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={handleCloseBooking}
        initialService={selectedService}
      />

      {/* Floating WhatsApp Action Widget */}
      <FloatingWhatsApp />
    </div>
  );
}
