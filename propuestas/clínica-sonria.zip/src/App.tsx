import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { StatsSection } from './components/StatsSection';
import { ServicesBento } from './components/ServicesBento';
import { ProcessSection } from './components/ProcessSection';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { BookingModal } from './components/BookingModal';

export default function App() {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);

  const handleOpenBooking = (serviceName?: string) => {
    setPreselectedService(serviceName);
    setIsBookingModalOpen(true);
  };

  const handleCloseBooking = () => {
    setIsBookingModalOpen(false);
    setPreselectedService(undefined);
  };

  const handleSelectServiceFromBento = (serviceName: string) => {
    handleOpenBooking(serviceName);
  };

  const handleSelectPlanFromPricing = (planName: string) => {
    handleOpenBooking(`Plan: ${planName}`);
  };

  return (
    <div className="min-h-screen bg-[#F5F7F7] text-[#4A4A4A] flex flex-col selection:bg-[#00897B] selection:text-white">
      {/* Liquid-Glass Navbar */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* Main Landing Flow */}
      <main className="flex-grow">
        {/* Hero Section with Cinematic Background & Fast Conversion */}
        <Hero onOpenBooking={() => handleOpenBooking()} />

        {/* 1. Stats & Trust Metrics */}
        <StatsSection />

        {/* 2. Services Bento Grid */}
        <ServicesBento onSelectServiceForBooking={handleSelectServiceFromBento} />

        {/* 3. How It Works / 3-Step Process */}
        <ProcessSection onOpenBooking={() => handleOpenBooking()} />

        {/* 4. Before & After Interactive Clinical Slider */}
        <BeforeAfterSlider />

        {/* 5. Patient Testimonials */}
        <TestimonialsSection />

        {/* 6. Pricing & Plans */}
        <PricingSection onSelectPlan={handleSelectPlanFromPricing} />

        {/* 7. Frequently Asked Questions Accordion */}
        <FaqSection />

        {/* 8. Final CTA & Interactive Contact / Appointment Form */}
        <ContactSection preselectedService={preselectedService} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Action Button */}
      <FloatingWhatsApp />

      {/* Fast Appointment Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={handleCloseBooking}
        preselectedService={preselectedService}
      />
    </div>
  );
}
