import React from 'react';
import { motion } from 'motion/react';
import { MessageSquareText, CalendarCheck2, UserCheck, ArrowRight, Clock, CheckCircle2 } from 'lucide-react';
import { PROCESS_STEPS } from '../data/dentalData';

interface ProcessSectionProps {
  onOpenBooking: () => void;
}

export const ProcessSection: React.FC<ProcessSectionProps> = ({ onOpenBooking }) => {
  const getStepIcon = (name: string) => {
    switch (name) {
      case 'MessageSquareText':
        return <MessageSquareText className="w-6 h-6 text-[#00897B]" />;
      case 'CalendarCheck2':
        return <CalendarCheck2 className="w-6 h-6 text-[#00897B]" />;
      case 'UserCheck':
        return <UserCheck className="w-6 h-6 text-[#00897B]" />;
      default:
        return <CheckCircle2 className="w-6 h-6 text-[#00897B]" />;
    }
  };

  return (
    <section id="proceso" className="py-20 lg:py-28 bg-white relative overflow-hidden">
      {/* Background soft ambient decoration */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-teal-50/70 rounded-full blur-3xl -translate-y-1/2 pointer-events-none" />
      <div className="absolute top-1/4 right-0 w-80 h-80 bg-orange-50/50 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-50 text-[#00897B] text-xs font-bold uppercase tracking-wider mb-3">
            Atención Rápida & Transparente
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#004B4F] tracking-tight">
            ¿Cómo funciona tu atención en Clínica Sonria?
          </h2>
          <p className="mt-4 text-base sm:text-lg text-gray-600">
            Diseñamos un flujo simple y digital sin esperas innecesarias para que tu visita sea cómoda y clara desde el primer minuto.
          </p>
        </div>

        {/* 3 Step Cards with Connectors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          
          {/* Connector Line (Desktop) */}
          <div className="hidden md:block absolute top-1/3 left-[15%] right-[15%] h-0.5 bg-gradient-to-r from-teal-200 via-[#00897B] to-teal-200 z-0" />

          {PROCESS_STEPS.map((step, index) => (
            <motion.div
              key={step.step}
              id={`process-step-card-${index + 1}`}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              className="relative z-10 bg-white rounded-2xl p-7 sm:p-8 shadow-lg shadow-teal-950/5 border border-teal-100 hover:border-[#00897B] hover:shadow-xl transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Step Number & Icon Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-teal-50 flex items-center justify-center border border-teal-100 group-hover:bg-[#00897B] group-hover:text-white transition-colors duration-300">
                    {getStepIcon(step.iconName)}
                  </div>
                  <span className="text-3xl font-black text-teal-200 group-hover:text-[#80CBC4] transition-colors">
                    {step.step}
                  </span>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-[#004B4F] tracking-tight mb-3">
                  {step.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  {step.description}
                </p>
              </div>

              <div className="pt-4 border-t border-gray-100 flex items-center gap-2 text-xs font-semibold text-[#00897B] bg-teal-50/50 p-2.5 rounded-xl">
                <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{step.detail}</span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Process Bottom Action */}
        <div className="mt-12 text-center">
          <button
            id="process-section-booking-cta"
            onClick={onOpenBooking}
            className="inline-flex items-center gap-3 bg-[#00897B] hover:bg-[#007367] text-white px-8 py-4 rounded-xl text-base font-bold shadow-md hover:scale-[1.02] transition-all cursor-pointer"
          >
            <span>Iniciar mi evaluación en 3 simples pasos</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
};
