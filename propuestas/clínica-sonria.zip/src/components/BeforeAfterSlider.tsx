import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, Clock, User, ArrowLeftRight } from 'lucide-react';
import { BEFORE_AFTER_CASES } from '../data/dentalData';

export const BeforeAfterSlider: React.FC = () => {
  const [activeCaseIndex, setActiveCaseIndex] = useState(0);
  const [sliderPosition, setSliderPosition] = useState(50); // percentage 0 to 100
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeCase = BEFORE_AFTER_CASES[activeCaseIndex];

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(5, Math.min(95, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      handleMove(e.clientX);
    }
  };

  return (
    <section id="casos" className="py-20 lg:py-28 bg-[#F5F7F7] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 text-[#004B4F] text-xs font-bold uppercase tracking-wider mb-3">
            Resultados Comprobados
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#004B4F] tracking-tight">
            Casos Clínicos: Antes y Después
          </h2>
          <p className="mt-4 text-base sm:text-lg text-gray-600">
            Desliza el comparador interactivo para apreciar la precisión milimétrica y la armonía estética de nuestros tratamientos.
          </p>
        </div>

        {/* Case Switcher Tabs */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-10">
          {BEFORE_AFTER_CASES.map((item, idx) => (
            <button
              key={item.id}
              id={`case-tab-${item.id}`}
              onClick={() => {
                setActiveCaseIndex(idx);
                setSliderPosition(50);
              }}
              className={`px-4 sm:px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeCaseIndex === idx
                  ? 'bg-[#004B4F] text-white shadow-md'
                  : 'bg-white text-gray-700 hover:bg-teal-50 hover:text-[#00897B] border border-gray-200'
              }`}
            >
              {item.title}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Card */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 lg:p-10 shadow-xl border border-teal-100/70">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Slider Column (7 cols) */}
            <div className="lg:col-span-7">
              <div
                ref={containerRef}
                id="before-after-interactive-container"
                className="relative h-[320px] sm:h-[420px] rounded-2xl overflow-hidden shadow-inner cursor-ew-resize select-none border border-gray-200"
                onMouseDown={() => setIsDragging(true)}
                onMouseUp={() => setIsDragging(false)}
                onMouseLeave={() => setIsDragging(false)}
                onMouseMove={handleMouseMove}
                onTouchMove={handleTouchMove}
              >
                {/* AFTER Image (Full Background) */}
                <img
                  src={activeCase.afterImage}
                  alt={`Resultado después: ${activeCase.title}`}
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none"
                />
                
                {/* AFTER Badge Label */}
                <div className="absolute top-4 right-4 z-10 bg-[#00897B] text-white text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-lg shadow-md pointer-events-none">
                  DESPUÉS
                </div>

                {/* BEFORE Image (Clipped Layer) */}
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{ width: `${sliderPosition}%` }}
                >
                  <img
                    src={activeCase.beforeImage}
                    alt={`Estado antes: ${activeCase.title}`}
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none"
                    style={{
                      width: containerRef.current?.clientWidth
                        ? `${containerRef.current.clientWidth}px`
                        : '100%',
                      maxWidth: 'none',
                    }}
                  />
                  {/* BEFORE Badge Label */}
                  <div className="absolute top-4 left-4 z-10 bg-gray-800/80 backdrop-blur-sm text-white text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-lg shadow-md">
                    ANTES
                  </div>
                </div>

                {/* Divider Line & Handle */}
                <div
                  className="absolute top-0 bottom-0 z-20 w-1 bg-white shadow-[0_0_10px_rgba(0,0,0,0.5)] cursor-ew-resize pointer-events-none"
                  style={{ left: `${sliderPosition}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-white text-[#004B4F] shadow-lg border-2 border-[#00897B] flex items-center justify-center pointer-events-auto">
                    <ArrowLeftRight className="w-4 h-4 text-[#00897B]" />
                  </div>
                </div>

                {/* Drag Hint at bottom */}
                <div className="absolute bottom-3 inset-x-0 flex justify-center pointer-events-none">
                  <span className="bg-black/60 backdrop-blur-sm text-white text-[11px] font-medium px-3 py-1 rounded-full flex items-center gap-1.5">
                    <ArrowLeftRight className="w-3 h-3" />
                    <span>Desliza para comparar antes y después</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Case Details Column (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              <div className="flex items-center gap-2">
                <span className="bg-teal-100 text-[#004B4F] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  {activeCase.treatment}
                </span>
                <span className="text-xs text-gray-500 font-medium flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-gray-400" />
                  <span>{activeCase.patientAge}</span>
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#004B4F] tracking-tight">
                {activeCase.title}
              </h3>

              <p className="text-sm sm:text-base text-gray-600 leading-relaxed">
                {activeCase.description}
              </p>

              <div className="p-4 rounded-xl bg-teal-50/60 border border-teal-100 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-[#004B4F] uppercase tracking-wider mb-1">
                  <Clock className="w-4 h-4 text-[#00897B]" />
                  <span>Duración del tratamiento: {activeCase.duration}</span>
                </div>
                {activeCase.highlights.map((h, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs sm:text-sm text-gray-700">
                    <CheckCircle2 className="w-4 h-4 text-[#00897B] flex-shrink-0" />
                    <span>{h}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 text-[11px] text-gray-400">
                * Casos clínicos ilustrativos de demostración realizados por especialistas certificados de Clínica Sonria.
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
