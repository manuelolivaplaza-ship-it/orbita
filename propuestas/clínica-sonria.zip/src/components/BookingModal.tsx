import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, CheckCircle2, MessageCircle, Clock, ShieldCheck, Sparkles, Send } from 'lucide-react';
import { SERVICES_DATA, CLINIC_INFO } from '../data/dentalData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedService?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  preselectedService,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState(preselectedService || 'Evaluación Inicial 3D');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('Mañana (09:00 - 13:00)');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const handleClose = () => {
    setIsSubmitted(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        id="booking-modal-backdrop"
        className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        onClick={handleClose}
      >
        <motion.div
          id="booking-modal-dialog"
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.25 }}
          className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative overflow-hidden my-8"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close button */}
          <button
            id="booking-modal-close-btn"
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>

          {isSubmitted ? (
            <div className="py-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-teal-100 text-[#00897B] mx-auto flex items-center justify-center shadow-md">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <h3 className="text-2xl font-extrabold text-[#004B4F]">
                ¡Hora reservada con éxito!
              </h3>

              <p className="text-sm text-gray-600 leading-relaxed">
                Gracias <strong className="text-gray-900">{name}</strong>. Te enviaremos la confirmación oficial a tu WhatsApp ({phone}) en menos de 15 minutos.
              </p>

              <div className="p-4 rounded-xl bg-teal-50 text-left text-xs text-gray-700 space-y-1 border border-teal-100">
                <div>• <strong>Tratamiento:</strong> {service}</div>
                <div>• <strong>Jornada:</strong> {preferredTime}</div>
                {preferredDate && <div>• <strong>Fecha propuesta:</strong> {preferredDate}</div>}
              </div>

              <div className="pt-3 flex flex-col gap-2">
                <a
                  href={`https://wa.me/56987654321?text=Hola%20Cl%C3%ADnica%20Sonria,%20agend%C3%A9%20una%20hora%20para%20${encodeURIComponent(
                    name
                  )}%20(${encodeURIComponent(service)})`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 bg-[#25D366] text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Validar por WhatsApp ahora</span>
                </a>

                <button
                  onClick={handleClose}
                  className="w-full py-2.5 text-xs text-gray-500 hover:text-gray-800 font-medium"
                >
                  Cerrar ventana
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center gap-2.5 mb-1">
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#00897B] flex items-center justify-center">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#004B4F] tracking-tight">
                    Agendar Evaluación Dental
                  </h3>
                  <p className="text-xs text-gray-500">
                    Clínica Sonria · Providencia, Santiago
                  </p>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                  Nombre completo *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Tu nombre y apellido"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                />
              </div>

              {/* Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Teléfono / WhatsApp *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+56 9 ..."
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="tu@email.com"
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                  />
                </div>
              </div>

              {/* Service selection */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                  Especialidad requerida
                </label>
                <select
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50 cursor-pointer"
                >
                  <option value="Evaluación Inicial 3D">Evaluación Inicial Integral 3D</option>
                  {SERVICES_DATA.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title}
                    </option>
                  ))}
                  <option value="Plan Preventivo Anual">Plan Preventivo Anual</option>
                  <option value="Urgencia Dental">Urgencia Inmediata</option>
                </select>
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Fecha preferente
                  </label>
                  <input
                    type="date"
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1">
                    Horario
                  </label>
                  <select
                    value={preferredTime}
                    onChange={(e) => setPreferredTime(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50 cursor-pointer"
                  >
                    <option value="Mañana (09:00 - 13:00)">Mañana (09:00 - 13:00)</option>
                    <option value="Tarde (13:00 - 17:00)">Tarde (13:00 - 17:00)</option>
                    <option value="Vespertino (17:00 - 19:00)">Vespertino (17:00 - 19:00)</option>
                    <option value="Sábado (09:00 - 14:00)">Sábado en la mañana</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-[#00897B] hover:bg-[#007367] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                >
                  {isSubmitting ? (
                    <span>Procesando...</span>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Confirmar reserva de hora</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[11px] text-gray-400">
                <ShieldCheck className="w-3.5 h-3.5 text-[#00897B]" />
                <span>Sin cobro anticipado · Cancelación gratuita</span>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
