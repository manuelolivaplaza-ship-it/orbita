import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { CLINIC_INFO } from '../data/dentalData';

export const FloatingWhatsApp: React.FC = () => {
  const [isTooltipDismissed, setIsTooltipDismissed] = useState(false);

  return (
    <div
      id="floating-whatsapp-container"
      className="fixed bottom-6 right-6 z-40 flex items-center gap-3"
    >
      {/* Interactive Tooltip / Help Bubble */}
      {!isTooltipDismissed && (
        <div
          id="whatsapp-tooltip-bubble"
          className="hidden sm:flex items-center gap-2 bg-white text-gray-800 px-4 py-2.5 rounded-2xl shadow-xl border border-gray-100 text-xs font-medium relative animate-bounce"
        >
          <div className="flex flex-col">
            <span className="font-bold text-[#004B4F]">¿Tienes dudas o urgencia?</span>
            <span className="text-gray-500">Chatea con una ejecutiva en vivo</span>
          </div>

          <button
            onClick={() => setIsTooltipDismissed(true)}
            className="text-gray-400 hover:text-gray-600 p-1 rounded-md"
            aria-label="Cerrar tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          {/* Tooltip Arrow */}
          <div className="absolute right-[-6px] top-1/2 -translate-y-1/2 w-3 h-3 bg-white rotate-45 border-t border-r border-gray-100" />
        </div>
      )}

      {/* Main WhatsApp Floating Button with Brand Color #25D366 */}
      <a
        id="floating-whatsapp-btn"
        href={CLINIC_INFO.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chatear por WhatsApp con Clínica Sonria"
        className="relative group w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300"
      >
        {/* Pulsing ring indicator */}
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-pulse-ring -z-10" />

        <MessageCircle className="w-7 h-7 fill-white" />
      </a>
    </div>
  );
};
