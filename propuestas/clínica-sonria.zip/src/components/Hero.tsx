import React from 'react';
import { motion } from 'motion/react';
import { Calendar, MessageCircle, Star, ShieldCheck, MapPin, Sparkles, CheckCircle2, Clock } from 'lucide-react';
import { CLINIC_INFO } from '../data/dentalData';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#004B4F]"
    >
      {/* Background Media Layer */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {/* Cinematic Video Background with fallback image */}
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover object-center scale-105 filter brightness-[0.65] contrast-[1.05]"
          poster="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1920&q=80"
        >
          <source
            src="https://assets.mixkit.co/videos/preview/mixkit-dentist-examining-a-patient-42171-large.mp4"
            type="video/mp4"
          />
        </video>

        {/* Cinematic Color Scrim & Gradients for WCAG AA legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#004B4F]/95 via-[#004B4F]/80 to-[#00897B]/45" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#004B4F] via-transparent to-black/30" />
      </div>

      {/* Decorative subtle ambient lights */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-[#80CBC4]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-[#FF6B4A]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Copy Column */}
          <div className="lg:col-span-8 text-white space-y-6">
            
            {/* Trust Rating Badge */}
            <motion.div
              id="hero-trust-badge"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-full text-xs sm:text-sm font-medium shadow-lg"
            >
              <div className="flex items-center text-amber-300">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-current" />
                ))}
              </div>
              <span className="text-white/90 font-semibold tracking-wide">
                4.9 ★ · +5.000 pacientes felices en Santiago
              </span>
              <span className="hidden sm:inline-block w-1.5 h-1.5 rounded-full bg-[#80CBC4]" />
              <span className="hidden sm:inline-block text-[#80CBC4] text-xs font-medium">
                Garantía Clínica
              </span>
            </motion.div>

            {/* Headline with tight tracking */}
            <motion.h1
              id="hero-headline"
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-[-0.03em] leading-[1.05] text-white"
            >
              Expertos en crear <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#80CBC4] via-white to-[#80CBC4]">
                sonrisas saludables
              </span>{' '}
              y radiantes
            </motion.h1>

            {/* Subhead */}
            <motion.p
              id="hero-subhead"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="text-lg sm:text-xl text-gray-200 max-w-2xl font-normal leading-relaxed"
            >
              Odontología de alta precisión en Santiago. Especialistas en{' '}
              <strong className="text-white font-semibold">ortodoncia invisible</strong>,{' '}
              <strong className="text-white font-semibold">implantes guiados 3D</strong> y{' '}
              <strong className="text-white font-semibold">estética dental</strong> con tecnología libre de dolor.
            </motion.p>

            {/* CTAs */}
            <motion.div
              id="hero-ctas-container"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4"
            >
              <button
                id="hero-primary-cta"
                onClick={onOpenBooking}
                className="group relative inline-flex items-center justify-center gap-3 bg-[#FF6B4A] hover:bg-[#ff5730] text-white px-8 py-4 rounded-xl text-base font-bold shadow-lg shadow-orange-950/30 hover:scale-[1.03] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Calendar className="w-5 h-5 transition-transform group-hover:rotate-6" />
                <span>Agendar evaluación</span>
              </button>

              <a
                id="hero-whatsapp-cta"
                href={CLINIC_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/30 px-7 py-4 rounded-xl text-base font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <MessageCircle className="w-5 h-5 text-[#25D366]" />
                <span>Hablar por WhatsApp</span>
              </a>
            </motion.div>

            {/* Highlights badges */}
            <motion.div
              id="hero-features-chips"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.45 }}
              className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs sm:text-sm text-gray-300"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#80CBC4]" />
                <span>Atención Fonasa & Reembolso Isapres</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#80CBC4]" />
                <span>Hasta 12 cuotas sin interés</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#80CBC4]" />
                <span>Metro Los Leones, Providencia</span>
              </div>
            </motion.div>
          </div>

          {/* Right Floating Card / Live Availability Box */}
          <motion.div
            id="hero-quick-card"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="lg:col-span-4 hidden lg:block"
          >
            <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-6 shadow-2xl border border-white/40 text-gray-800 relative">
              <div className="absolute -top-3 right-6 bg-[#00897B] text-white text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-md">
                Disponibilidad Inmediata
              </div>

              <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center text-[#00897B]">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-base">Evaluación Integral 3D</h3>
                  <p className="text-xs text-gray-500">Diagnóstico digital completo</p>
                </div>
              </div>

              <div className="space-y-3 py-4 text-xs text-gray-600">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-gray-50">
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#00897B]" />
                    <span>Próximas horas disponibles:</span>
                  </span>
                  <span className="font-bold text-[#004B4F] bg-teal-100/70 px-2 py-0.5 rounded">
                    Hoy / Mañana
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-gray-50">
                  <span className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#00897B]" />
                    <span>Radiografías digitales:</span>
                  </span>
                  <span className="font-semibold text-emerald-700">Incluidas</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-lg bg-gray-50">
                  <span className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#00897B]" />
                    <span>Sector:</span>
                  </span>
                  <span className="font-semibold text-gray-800">Providencia, Santiago</span>
                </div>
              </div>

              <button
                id="hero-card-booking-btn"
                onClick={onOpenBooking}
                className="w-full mt-2 py-3 bg-[#00897B] hover:bg-[#007367] text-white font-semibold text-sm rounded-xl shadow-md transition-all hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Reservar hora online</span>
              </button>

              <p className="text-[11px] text-center text-gray-400 mt-2">
                Sin compromiso · Confirmación instantánea
              </p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
