import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  Clock,
  CheckCircle2,
  Send,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { CLINIC_INFO, SERVICES_DATA } from '../data/dentalData';
import { AppointmentFormState } from '../types';

interface ContactSectionProps {
  preselectedService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ preselectedService }) => {
  const [formData, setFormData] = useState<AppointmentFormState>({
    name: '',
    email: '',
    phone: '',
    specialty: preselectedService || 'Evaluación Inicial 3D',
    preferredDate: '',
    preferredTime: 'Mañana (09:00 - 13:00)',
    notes: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!formData.name.trim() || !formData.email.trim() || !formData.phone.trim()) {
      setErrorMessage('Por favor completa todos los campos obligatorios (*)');
      return;
    }

    setIsSubmitting(true);

    // Simulate instant secure submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const handleResetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      specialty: 'Evaluación Inicial 3D',
      preferredDate: '',
      preferredTime: 'Mañana (09:00 - 13:00)',
      notes: '',
    });
    setIsSubmitted(false);
  };

  return (
    <section id="contacto" className="py-20 lg:py-28 bg-[#004B4F] text-white relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute -top-24 right-0 w-96 h-96 bg-[#00897B]/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 left-0 w-96 h-96 bg-[#FF6B4A]/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Call to Action Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-[#80CBC4] text-xs font-bold uppercase tracking-wider mb-3 border border-white/10">
            Agenda tu Evaluación
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
            Comienza hoy a transformar tu sonrisa
          </h2>
          <p className="mt-4 text-base sm:text-lg text-teal-100 max-w-2xl mx-auto">
            Completa el formulario en 1 minuto o escríbenos directamente. Un odontólogo especialista revisará tu solicitud para confirmar tu hora.
          </p>
        </div>

        {/* 2-Column Contact Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          
          {/* Left Column: Clinic Contact Info & Advantages (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Info Card */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 sm:p-8 border border-white/15 space-y-6">
              <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#80CBC4]" />
                <span>Información de Contacto</span>
              </h3>

              <div className="space-y-4 text-sm text-teal-100">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-800/80 flex items-center justify-center text-[#80CBC4] flex-shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block font-semibold">Dirección:</strong>
                    <span>{CLINIC_INFO.address}</span>
                    <p className="text-xs text-[#80CBC4] mt-0.5">{CLINIC_INFO.metroNear}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-800/80 flex items-center justify-center text-[#80CBC4] flex-shrink-0 mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block font-semibold">Teléfono directo:</strong>
                    <a href={`tel:${CLINIC_INFO.phone}`} className="hover:text-white underline">
                      {CLINIC_INFO.phoneDisplay}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-800/80 flex items-center justify-center text-[#80CBC4] flex-shrink-0 mt-0.5">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block font-semibold">Correo de contacto:</strong>
                    <a href={`mailto:${CLINIC_INFO.email}`} className="hover:text-white underline">
                      {CLINIC_INFO.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-teal-800/80 flex items-center justify-center text-[#80CBC4] flex-shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block font-semibold">Horarios de atención:</strong>
                    <p className="text-xs text-teal-100">{CLINIC_INFO.hours.weekdays}</p>
                    <p className="text-xs text-teal-100">{CLINIC_INFO.hours.saturdays}</p>
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Action Button */}
              <div className="pt-2">
                <a
                  id="contact-whatsapp-fast-btn"
                  href={CLINIC_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all hover:scale-[1.02]"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Chatear por WhatsApp ahora</span>
                </a>
              </div>
            </div>

            {/* Trust Pill */}
            <div className="bg-teal-900/60 border border-teal-700/60 rounded-2xl p-5 flex items-center gap-4 text-xs text-teal-200">
              <ShieldCheck className="w-8 h-8 text-[#80CBC4] flex-shrink-0" />
              <div>
                <strong className="text-white block text-sm mb-0.5">Atención Privada & Segura</strong>
                Tus datos de contacto son tratados con estricta confidencialidad médica según la ley chilena.
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Appointment Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-2xl text-gray-800 relative">
              
              <AnimatePresence mode="wait">
                {isSubmitted ? (
                  <motion.div
                    key="success-message"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="py-10 text-center space-y-5"
                  >
                    <div className="w-16 h-16 rounded-full bg-teal-100 text-[#00897B] mx-auto flex items-center justify-center shadow-md">
                      <CheckCircle2 className="w-10 h-10" />
                    </div>

                    <h3 className="text-2xl font-extrabold text-[#004B4F]">
                      ¡Solicitud de evaluación recibida!
                    </h3>

                    <p className="text-sm sm:text-base text-gray-600 max-w-md mx-auto leading-relaxed">
                      Estimado/a <strong className="text-gray-900">{formData.name}</strong>, nos pondremos en contacto contigo a la brevedad a través de{' '}
                      <strong className="text-gray-900">{formData.phone}</strong> o tu correo para confirmar el horario exacto para tu consulta de{' '}
                      <strong className="text-[#00897B]">{formData.specialty}</strong>.
                    </p>

                    <div className="p-4 rounded-xl bg-teal-50 text-left text-xs text-gray-700 space-y-1.5 max-w-sm mx-auto border border-teal-100">
                      <div className="font-bold text-[#004B4F] mb-1">Resumen de tu solicitud:</div>
                      <div>• <strong>Especialidad:</strong> {formData.specialty}</div>
                      <div>• <strong>Horario preferente:</strong> {formData.preferredTime}</div>
                      {formData.preferredDate && <div>• <strong>Fecha propuesta:</strong> {formData.preferredDate}</div>}
                    </div>

                    <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                      <a
                        href={`https://wa.me/56987654321?text=Hola%20Cl%C3%ADnica%20Sonria,%20acabo%20de%20enviar%20una%20solicitud%20para%20${encodeURIComponent(
                          formData.name
                        )}%20(${encodeURIComponent(formData.specialty)})`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-3 px-6 bg-[#25D366] text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Confirmar de inmediato por WhatsApp</span>
                      </a>

                      <button
                        onClick={handleResetForm}
                        className="py-3 px-5 border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold rounded-xl text-sm cursor-pointer"
                      >
                        Enviar otra consulta
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.form
                    key="appointment-form"
                    id="contact-form"
                    onSubmit={handleSubmit}
                    className="space-y-4"
                  >
                    <div>
                      <h3 className="text-2xl font-extrabold text-[#004B4F] tracking-tight">
                        Formulario de Agendamiento
                      </h3>
                      <p className="text-xs sm:text-sm text-gray-500 mt-1">
                        Ingresa tus datos y te contactaremos en menos de 15 minutos.
                      </p>
                    </div>

                    {errorMessage && (
                      <div className="p-3 rounded-xl bg-red-50 text-red-600 text-xs font-semibold border border-red-200">
                        {errorMessage}
                      </div>
                    )}

                    {/* Name */}
                    <div>
                      <label htmlFor="form-name" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Nombre y Apellido *
                      </label>
                      <input
                        type="text"
                        id="form-name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Ej. Ana Morales"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                      />
                    </div>

                    {/* Email & Phone 2-Col */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="form-email" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                          Correo Electrónico *
                        </label>
                        <input
                          type="email"
                          id="form-email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="tu@correo.cl"
                          required
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                        />
                      </div>

                      <div>
                        <label htmlFor="form-phone" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                          Teléfono o WhatsApp *
                        </label>
                        <input
                          type="tel"
                          id="form-phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          placeholder="+56 9 1234 5678"
                          required
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                        />
                      </div>
                    </div>

                    {/* Specialty & Preferred Time */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="form-specialty" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                          Especialidad de Interés
                        </label>
                        <select
                          id="form-specialty"
                          name="specialty"
                          value={formData.specialty}
                          onChange={handleChange}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50 cursor-pointer"
                        >
                          <option value="Evaluación Inicial 3D">Evaluación Inicial Integral 3D</option>
                          {SERVICES_DATA.map((svc) => (
                            <option key={svc.id} value={svc.title}>
                              {svc.title}
                            </option>
                          ))}
                          <option value="Plan Preventivo Anual">Plan Preventivo Anual</option>
                          <option value="Urgencia Dental Inmediata">Urgencia Dental / Dolor Agudo</option>
                        </select>
                      </div>

                      <div>
                        <label htmlFor="form-preferred-time" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                          Jornada Preferida
                        </label>
                        <select
                          id="form-preferred-time"
                          name="preferredTime"
                          value={formData.preferredTime}
                          onChange={handleChange}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50 cursor-pointer"
                        >
                          <option value="Mañana (09:00 - 13:00)">Mañana (09:00 - 13:00)</option>
                          <option value="Tarde (13:00 - 17:00)">Tarde (13:00 - 17:00)</option>
                          <option value="Vespertino (17:00 - 19:00)">Vespertino (17:00 - 19:00)</option>
                          <option value="Sábado (09:00 - 14:00)">Sábado en la mañana</option>
                        </select>
                      </div>
                    </div>

                    {/* Preferred Date Optional */}
                    <div>
                      <label htmlFor="form-date" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Fecha Estimada (Opcional)
                      </label>
                      <input
                        type="date"
                        id="form-date"
                        name="preferredDate"
                        value={formData.preferredDate}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50"
                      />
                    </div>

                    {/* Message / Motivo */}
                    <div>
                      <label htmlFor="form-notes" className="block text-xs font-bold uppercase tracking-wider text-gray-700 mb-1.5">
                        Mensaje o síntoma (Opcional)
                      </label>
                      <textarea
                        id="form-notes"
                        name="notes"
                        value={formData.notes}
                        onChange={handleChange}
                        rows={3}
                        placeholder="Ej. Quiero saber si califico para ortodoncia invisible..."
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#00897B] text-sm text-gray-900 bg-gray-50/50 resize-none"
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="pt-2">
                      <button
                        type="submit"
                        id="contact-form-submit-btn"
                        disabled={isSubmitting}
                        className="w-full py-4 bg-[#00897B] hover:bg-[#007367] text-white font-bold rounded-xl text-base shadow-lg shadow-teal-950/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
                      >
                        {isSubmitting ? (
                          <span>Enviando solicitud...</span>
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            <span>Solicitar mi evaluación ahora</span>
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-[11px] text-center text-gray-400">
                      Sin cobro por agendamiento. Confirmaremos la disponibilidad de la hora con un especialista.
                    </p>
                  </motion.form>
                )}
              </AnimatePresence>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
