import React from 'react';
import { motion } from 'motion/react';
import { Award, Users, Star, ShieldCheck } from 'lucide-react';
import { STATS_DATA } from '../data/dentalData';

export const StatsSection: React.FC = () => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Award':
        return <Award className="w-7 h-7 text-[#00897B]" />;
      case 'Users':
        return <Users className="w-7 h-7 text-[#00897B]" />;
      case 'Star':
        return <Star className="w-7 h-7 text-amber-500 fill-amber-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-7 h-7 text-[#00897B]" />;
      default:
        return <ShieldCheck className="w-7 h-7 text-[#00897B]" />;
    }
  };

  return (
    <section id="stats" className="relative -mt-8 z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-white rounded-2xl shadow-xl shadow-teal-950/5 border border-teal-100/60 p-6 sm:p-8 lg:p-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 divide-y sm:divide-y-0 sm:divide-x divide-gray-100">
          {STATS_DATA.map((stat, index) => (
            <motion.div
              key={stat.label}
              id={`stat-card-${index}`}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`flex items-start gap-4 ${
                index !== 0 ? 'pt-6 sm:pt-0 sm:pl-6 lg:pl-8' : ''
              }`}
            >
              <div className="p-3.5 rounded-xl bg-teal-50/80 border border-teal-100 flex-shrink-0 flex items-center justify-center">
                {getIcon(stat.iconName)}
              </div>
              <div className="flex-1">
                <div className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#004B4F] tracking-tight">
                  {stat.value}
                </div>
                <div className="text-sm font-bold text-gray-800 mt-0.5">
                  {stat.label}
                </div>
                <p className="text-xs text-gray-500 mt-1 leading-snug">
                  {stat.subtext}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
