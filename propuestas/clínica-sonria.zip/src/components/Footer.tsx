import React from 'react';
import { Phone, Mail, MapPin, Clock, ShieldCheck, Heart, ArrowUp } from 'lucide-react';
import { CLINIC_INFO } from '../data/dentalData';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-[#002D30] text-gray-300 pt-16 pb-12 border-t border-teal-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-Column Footer */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-teal-900/80">
          
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#00897B] flex items-center justify-center text-white shadow-md">
                <svg
                  className="w-6 h-6"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2C8.5 2 6 4.5 6 7.5C6 9.5 7 11.5 7.5 13.5C8 15.5 8.2 19 9.5 21C10.5 22.5 11.5 21.5 12 19C12.5 21.5 13.5 22.5 14.5 21C15.8 19 16 15.5 16.5 13.5C17 11.5 18 9.5 18 7.5C18 4.5 15.5 2 12 2Z"
                    fill="currentColor"
                    fillOpacity="0.3"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9 8.5C10 10 14 10 15 8.5"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              <span className="text-xl font-bold text-white tracking-tight">
                Clínica <span className="text-[#80CBC4]">Sonria</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-gray-400 leading-relaxed">
              {CLINIC_INFO.tagline}. Odontología de alta precisión en Santiago, enfocada en una experiencia cálida, moderna y libre de dolor.
            </p>

            <div className="flex items-center gap-2 text-xs text-[#80CBC4] font-medium pt-1">
              <ShieldCheck className="w-4 h-4 text-[#00897B]" />
              <span>Acreditación Sanitaria Superintendencia de Salud</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Navegación
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">
                  Inicio
                </a>
              </li>
              <li>
                <a href="#especialidades" className="hover:text-white transition-colors">
                  Especialidades Médicas
                </a>
              </li>
              <li>
                <a href="#proceso" className="hover:text-white transition-colors">
                  Cómo Funciona
                </a>
              </li>
              <li>
                <a href="#casos" className="hover:text-white transition-colors">
                  Casos de Antes y Después
                </a>
              </li>
              <li>
                <a href="#precios" className="hover:text-white transition-colors">
                  Planes y Aranceles
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Preguntas Frecuentes
                </a>
              </li>
              <li>
                <a href="#contacto" className="hover:text-white transition-colors">
                  Contacto y Ubicación
                </a>
              </li>
            </ul>
          </div>

          {/* Treatments Col */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Tratamientos Principales
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-gray-400">
              <li>Ortodoncia Invisible 3D</li>
              <li>Implantes Dentales de Titanio</li>
              <li>Estética & Carillas E-Max</li>
              <li>Blanqueamiento Dental Láser</li>
              <li>Endodoncia con Microscopio</li>
              <li>Odontopediatría Integral</li>
              <li>Profilaxis y Limpieza Ultrasónica</li>
            </ul>
          </div>

          {/* Clinic Hours & Contact */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white">
              Horario & Ubicación
            </h4>
            <div className="space-y-2.5 text-xs sm:text-sm text-gray-400">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-[#80CBC4] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Lunes a Viernes</p>
                  <p className="text-xs">09:00 - 19:00 hrs</p>
                  <p className="text-white font-medium mt-1">Sábados</p>
                  <p className="text-xs">09:00 - 14:00 hrs</p>
                </div>
              </div>

              <div className="flex items-start gap-2 pt-2">
                <MapPin className="w-4 h-4 text-[#80CBC4] flex-shrink-0 mt-0.5" />
                <span>{CLINIC_INFO.address} ({CLINIC_INFO.metroNear})</span>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <Phone className="w-4 h-4 text-[#80CBC4] flex-shrink-0" />
                <a href={`tel:${CLINIC_INFO.phone}`} className="text-white hover:underline">
                  {CLINIC_INFO.phoneDisplay}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <p>
            © {currentYear} Clínica Sonria (Demo de Presentación). Todos los derechos reservados.
          </p>

          <div className="flex items-center gap-4">
            <span className="text-gray-400">Santiago, Chile</span>
            <button
              id="scroll-to-top-btn"
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-teal-900 hover:bg-teal-800 text-white transition-colors cursor-pointer flex items-center gap-1 text-xs"
              aria-label="Volver arriba"
            >
              <span>Subir</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
