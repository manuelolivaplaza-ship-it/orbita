import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Phone, Calendar, ArrowRight, ShieldCheck } from 'lucide-react';
import { CLINIC_INFO } from '../data/dentalData';

interface NavbarProps {
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Prevent scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMobileMenuOpen]);

  const navLinks = [
    { name: 'Inicio', href: '#inicio' },
    { name: 'Especialidades', href: '#especialidades' },
    { name: 'Proceso', href: '#proceso' },
    { name: 'Casos Clínicos', href: '#casos' },
    { name: 'Planes & Precios', href: '#precios' },
    { name: 'Preguntas', href: '#faq' },
    { name: 'Contacto', href: '#contacto' },
  ];

  const handleLinkClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        id="navbar-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/90 backdrop-blur-md shadow-sm py-3 border-b border-teal-100/50'
            : 'bg-gradient-to-b from-black/40 via-black/10 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              id="brand-logo-link"
              href="#inicio"
              className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-[#00897B] rounded-lg p-1"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#004B4F] to-[#00897B] flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-200">
                {/* Custom Stylized Tooth & Smile SVG */}
                <svg
                  className="w-6 h-6 text-white"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2C8.5 2 6 4.5 6 7.5C6 9.5 7 11.5 7.5 13.5C8 15.5 8.2 19 9.5 21C10.5 22.5 11.5 21.5 12 19C12.5 21.5 13.5 22.5 14.5 21C15.8 19 16 15.5 16.5 13.5C17 11.5 18 9.5 18 7.5C18 4.5 15.5 2 12 2Z"
                    fill="currentColor"
                    fillOpacity="0.3"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M9 8.5C10 10 14 10 15 8.5"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              <div className="flex flex-col">
                <span
                  className={`text-xl font-bold tracking-tight transition-colors ${
                    isScrolled ? 'text-[#004B4F]' : 'text-white drop-shadow-md'
                  }`}
                >
                  Clínica <span className="text-[#00897B]">Sonria</span>
                </span>
                <span
                  className={`text-[10px] uppercase tracking-wider font-semibold ${
                    isScrolled ? 'text-gray-500' : 'text-gray-200 drop-shadow-sm'
                  }`}
                >
                  Odontología Integral Santiago
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav id="desktop-nav" className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  id={`nav-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => handleLinkClick(link.href)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    isScrolled
                      ? 'text-gray-700 hover:text-[#00897B] hover:bg-teal-50/50'
                      : 'text-white/90 hover:text-white hover:bg-white/10 drop-shadow-sm'
                  }`}
                >
                  {link.name}
                </button>
              ))}
            </nav>

            {/* Right Action buttons */}
            <div className="hidden sm:flex items-center gap-3">
              <a
                id="navbar-phone-btn"
                href={`tel:${CLINIC_INFO.phone}`}
                className={`hidden xl:flex items-center gap-2 text-xs font-semibold px-3 py-2 rounded-xl transition-all ${
                  isScrolled
                    ? 'text-[#004B4F] bg-teal-50 hover:bg-teal-100/70'
                    : 'text-white bg-black/20 backdrop-blur-sm border border-white/20 hover:bg-black/30'
                }`}
              >
                <Phone className="w-3.5 h-3.5 text-[#00897B]" />
                <span>{CLINIC_INFO.phoneDisplay}</span>
              </a>

              <button
                id="navbar-booking-cta"
                onClick={onOpenBooking}
                className="flex items-center gap-2 bg-[#00897B] hover:bg-[#007367] text-white px-4 py-2.5 rounded-xl text-sm font-semibold shadow-sm hover:shadow-md hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Agendar evaluación</span>
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                id="mobile-quick-book-btn"
                onClick={onOpenBooking}
                className="sm:hidden flex items-center justify-center p-2 rounded-xl bg-[#00897B] text-white shadow-sm"
                aria-label="Agendar evaluación"
              >
                <Calendar className="w-4 h-4" />
              </button>
              <button
                id="mobile-menu-toggle-btn"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={`p-2.5 rounded-xl transition-colors cursor-pointer ${
                  isScrolled
                    ? 'text-gray-800 hover:bg-gray-100'
                    : 'text-white bg-black/20 backdrop-blur-sm hover:bg-black/30'
                }`}
                aria-label="Abrir menú"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-menu-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <motion.div
              id="mobile-menu-drawer"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute top-0 right-0 bottom-0 w-[85%] max-w-sm bg-white shadow-2xl p-6 flex flex-col justify-between overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div>
                {/* Header in Drawer */}
                <div className="flex items-center justify-between pb-6 border-b border-gray-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-[#004B4F] to-[#00897B] flex items-center justify-center text-white">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="font-bold text-[#004B4F] text-lg">Clínica Sonria</span>
                      <p className="text-[11px] text-gray-500">Santiago, Chile</p>
                    </div>
                  </div>
                  <button
                    id="mobile-menu-close-btn"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-2 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"
                    aria-label="Cerrar menú"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                {/* Nav Links */}
                <nav className="mt-6 flex flex-col gap-2">
                  {navLinks.map((link, index) => (
                    <motion.button
                      key={link.name}
                      id={`mobile-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      onClick={() => handleLinkClick(link.href)}
                      className="flex items-center justify-between w-full px-4 py-3 rounded-xl text-left text-gray-700 font-medium hover:bg-teal-50 hover:text-[#00897B] transition-colors"
                    >
                      <span>{link.name}</span>
                      <ArrowRight className="w-4 h-4 text-gray-400" />
                    </motion.button>
                  ))}
                </nav>
              </div>

              {/* Bottom Actions in Drawer */}
              <div className="pt-6 border-t border-gray-100 flex flex-col gap-3">
                <button
                  id="mobile-menu-booking-btn"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenBooking();
                  }}
                  className="w-full py-3.5 bg-[#00897B] text-white font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Agendar evaluación</span>
                </button>

                <a
                  id="mobile-menu-whatsapp-btn"
                  href={CLINIC_INFO.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 bg-[#25D366] text-white font-semibold rounded-xl flex items-center justify-center gap-2 text-sm shadow-sm"
                >
                  <span>Hablar por WhatsApp</span>
                </a>

                <div className="text-center text-xs text-gray-500 pt-2">
                  <p className="font-semibold text-gray-700">{CLINIC_INFO.phoneDisplay}</p>
                  <p>Lun a Vie 09:00 - 19:00 | Sáb 09:00 - 14:00</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
