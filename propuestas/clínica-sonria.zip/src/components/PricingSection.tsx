import React from 'react';
import { motion } from 'motion/react';
import { Check, Calendar, ArrowRight, ShieldCheck, Sparkles, CreditCard } from 'lucide-react';
import { PRICING_PLANS } from '../data/dentalData';

interface PricingSectionProps {
  onSelectPlan: (planName: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  return (
    <section id="precios" className="py-20 lg:py-28 bg-[#F5F7F7] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 text-[#004B4F] text-xs font-bold uppercase tracking-wider mb-3">
            Transparencia Total
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#004B4F] tracking-tight">
            Planes y aranceles claros para tu salud dental
          </h2>
          <p className="mt-4 text-base sm:text-lg text-gray-600">
            Sin costos ocultos ni letras chicas. Facilidades de financiamiento en hasta 12 cuotas sin interés y convenios de reembolso.
          </p>
        </div>

        {/* 3 Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRICING_PLANS.map((plan, index) => {
            const isPopular = plan.isPopular;

            return (
              <motion.div
                key={plan.id}
                id={`pricing-card-${plan.id}`}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.12 }}
                className={`relative rounded-3xl p-7 sm:p-9 flex flex-col justify-between transition-all ${
                  isPopular
                    ? 'bg-[#004B4F] text-white shadow-2xl shadow-teal-950/20 border-2 border-[#00897B] lg:-translate-y-3'
                    : 'bg-white text-gray-800 shadow-lg border border-gray-200/80 hover:shadow-xl'
                }`}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[#FF6B4A] text-white text-xs font-bold uppercase tracking-wider px-4 py-1.5 rounded-full shadow-md flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{plan.badge || 'Más Elegido'}</span>
                  </div>
                )}

                {!isPopular && plan.badge && (
                  <div className="inline-block self-start bg-teal-50 text-[#00897B] text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-3 border border-teal-100">
                    {plan.badge}
                  </div>
                )}

                <div>
                  {/* Plan Name & Tagline */}
                  <h3
                    className={`text-2xl font-bold tracking-tight mb-1 ${
                      isPopular ? 'text-white' : 'text-[#004B4F]'
                    }`}
                  >
                    {plan.name}
                  </h3>
                  <p
                    className={`text-xs sm:text-sm mb-6 ${
                      isPopular ? 'text-teal-200' : 'text-gray-500'
                    }`}
                  >
                    {plan.tagline}
                  </p>

                  {/* Price */}
                  <div className="mb-4">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-4xl sm:text-5xl font-black tracking-tight">
                        {plan.price}
                      </span>
                      {plan.period && (
                        <span
                          className={`text-xs font-semibold ${
                            isPopular ? 'text-teal-200' : 'text-gray-500'
                          }`}
                        >
                          {plan.period}
                        </span>
                      )}
                    </div>
                    <div
                      className={`text-xs font-medium mt-1.5 flex items-center gap-1.5 ${
                        isPopular ? 'text-teal-100' : 'text-gray-600'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>{plan.installments}</span>
                    </div>
                  </div>

                  {/* Divider */}
                  <div
                    className={`h-px w-full my-6 ${
                      isPopular ? 'bg-teal-800' : 'bg-gray-100'
                    }`}
                  />

                  {/* Feature list */}
                  <div className="space-y-3.5 mb-8">
                    <p
                      className={`text-xs font-bold uppercase tracking-wider ${
                        isPopular ? 'text-teal-300' : 'text-gray-400'
                      }`}
                    >
                      Incluye:
                    </p>
                    {plan.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm">
                        <div
                          className={`p-1 rounded-full flex-shrink-0 mt-0.5 ${
                            isPopular
                              ? 'bg-teal-600/60 text-[#80CBC4]'
                              : 'bg-teal-50 text-[#00897B]'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <span
                          className={
                            isPopular ? 'text-teal-50' : 'text-gray-700'
                          }
                        >
                          {feat}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Plan Action CTA */}
                <button
                  id={`pricing-cta-${plan.id}`}
                  onClick={() => onSelectPlan(plan.name)}
                  className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isPopular
                      ? 'bg-[#FF6B4A] hover:bg-[#ff5730] text-white shadow-lg hover:scale-[1.02]'
                      : 'bg-[#00897B] hover:bg-[#007367] text-white shadow-md hover:scale-[1.02]'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  <span>{plan.ctaText}</span>
                </button>
              </motion.div>
            );
          })}
        </div>

        {/* Financing Notice */}
        <div className="mt-12 text-center text-xs text-gray-500 max-w-2xl mx-auto">
          * Valores de referencia para demostración. Aceptamos tarjetas de crédito con cuotas sin interés, tarjetas de débito, transferencias y reembolso para todas las Isapres y seguros complementarios.
        </div>

      </div>
    </section>
  );
};
