import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Shield,
  Smile,
  CheckCircle2,
  Activity,
  HeartHandshake,
  ArrowRight,
  Clock,
  X,
  Calendar,
} from 'lucide-react';
import { SERVICES_DATA } from '../data/dentalData';
import { DentalService } from '../types';

interface ServicesBentoProps {
  onSelectServiceForBooking: (serviceName: string) => void;
}

export const ServicesBento: React.FC<ServicesBentoProps> = ({ onSelectServiceForBooking }) => {
  const [selectedService, setSelectedService] = useState<DentalService | null>(null);

  const getServiceIcon = (iconName: string, className = 'w-6 h-6') => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className={className} />;
      case 'Shield':
        return <Shield className={className} />;
      case 'Smile':
        return <Smile className={className} />;
      case 'CheckCircle2':
        return <CheckCircle2 className={className} />;
      case 'Activity':
        return <Activity className={className} />;
      case 'HeartHandshake':
        return <HeartHandshake className={className} />;
      default:
        return <Sparkles className={className} />;
    }
  };

  return (
    <section id="especialidades" className="py-20 lg:py-28 bg-[#F5F7F7] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 text-[#004B4F] text-xs font-bold uppercase tracking-wider mb-3">
            Especialidades Médicas
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#004B4F] tracking-tight">
            Tratamientos de alta precisión para cada necesidad
          </h2>
          <p className="mt-4 text-base sm:text-lg text-gray-600">
            Combinamos experiencia clínica con equipamiento 3D de última generación para ofrecerte resultados duraderos y sin dolor.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {SERVICES_DATA.map((service, index) => {
            // Card styling according to bgType
            if (service.bgType === 'image') {
              return (
                <motion.div
                  key={service.id}
                  id={`service-card-${service.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="group relative md:col-span-2 lg:col-span-2 rounded-2xl overflow-hidden shadow-lg min-h-[340px] flex flex-col justify-end p-6 sm:p-8 cursor-pointer border border-teal-900/10"
                  onClick={() => setSelectedService(service)}
                >
                  {/* Background Image & Scrim */}
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#004B4F] via-[#004B4F]/75 to-black/30" />

                  {/* Badge */}
                  {service.badge && (
                    <div className="absolute top-6 left-6 z-10 bg-[#FF6B4A] text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-md">
                      {service.badge}
                    </div>
                  )}

                  {/* Content */}
                  <div className="relative z-10 text-white space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/20">
                      {getServiceIcon(service.iconName, 'w-6 h-6')}
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                      {service.title}
                    </h3>
                    <p className="text-gray-200 text-sm sm:text-base max-w-xl line-clamp-2">
                      {service.shortDesc}
                    </p>

                    <div className="pt-2 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-[#80CBC4] font-medium">
                        <Clock className="w-4 h-4" />
                        <span>{service.duration}</span>
                      </div>
                      <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-white group-hover:text-[#80CBC4] transition-colors">
                        <span>Ver detalles clínicos</span>
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </span>
                    </div>
                  </div>
                </motion.div>
              );
            }

            if (service.bgType === 'solid-dark') {
              return (
                <motion.div
                  key={service.id}
                  id={`service-card-${service.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.08 }}
                  className="group relative rounded-2xl bg-[#004B4F] text-white p-6 sm:p-8 flex flex-col justify-between shadow-lg shadow-teal-950/15 border border-teal-800 cursor-pointer hover:shadow-xl transition-all"
                  onClick={() => setSelectedService(service)}
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-teal-700/50 flex items-center justify-center text-[#80CBC4] border border-teal-600/40">
                        {getServiceIcon(service.iconName, 'w-6 h-6')}
                      </div>
                      {service.badge && (
                        <span className="bg-[#00897B] text-white text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
                          {service.badge}
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight mb-2">
                      {service.title}
                    </h3>
                    <p className="text-sm text-teal-100/90 leading-relaxed">
                      {service.shortDesc}
                    </p>
                  </div>

                  <div className="pt-6 border-t border-teal-800/80 mt-6 flex items-center justify-between">
                    <span className="text-xs text-[#80CBC4] font-medium flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{service.duration}</span>
                    </span>
                    <span className="text-xs font-bold text-white group-hover:text-[#80CBC4] inline-flex items-center gap-1">
                      <span>Detalles</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </motion.div>
              );
            }

            // Standard Light / Accent cards
            const isAccent = service.bgType === 'accent';

            return (
              <motion.div
                key={service.id}
                id={`service-card-${service.id}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className={`group rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-md hover:shadow-xl transition-all border cursor-pointer ${
                  isAccent
                    ? 'bg-gradient-to-br from-white to-teal-50/70 border-teal-200'
                    : 'bg-white border-gray-100 hover:border-teal-200'
                }`}
                onClick={() => setSelectedService(service)}
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center text-[#00897B] mb-4 border border-teal-100 group-hover:bg-[#00897B] group-hover:text-white transition-colors duration-200">
                    {getServiceIcon(service.iconName, 'w-6 h-6')}
                  </div>
                  <h3 className="text-xl font-bold text-[#004B4F] tracking-tight mb-2">
                    {service.title}
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {service.shortDesc}
                  </p>
                </div>

                <div className="pt-6 border-t border-gray-100 mt-6 flex items-center justify-between">
                  <span className="text-xs text-gray-500 font-medium flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#00897B]" />
                    <span>{service.duration}</span>
                  </span>
                  <span className="text-xs font-bold text-[#00897B] group-hover:text-[#004B4F] inline-flex items-center gap-1">
                    <span>Saber más</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {selectedService && (
          <motion.div
            id="service-detail-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedService(null)}
          >
            <motion.div
              id="service-detail-modal-content"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                id="service-detail-modal-close"
                onClick={() => setSelectedService(null)}
                className="absolute top-4 right-4 p-2 rounded-xl text-gray-400 hover:text-gray-700 hover:bg-gray-100 cursor-pointer"
                aria-label="Cerrar modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center text-[#00897B]">
                  {getServiceIcon(selectedService.iconName)}
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider font-bold text-[#00897B]">
                    Especialidad Clínica
                  </span>
                  <h3 className="text-xl font-bold text-[#004B4F]">
                    {selectedService.title}
                  </h3>
                </div>
              </div>

              <p className="text-sm text-gray-600 leading-relaxed mb-6">
                {selectedService.fullDesc}
              </p>

              <div className="space-y-2.5 mb-6">
                <h4 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                  Beneficios y características clave:
                </h4>
                {selectedService.benefits.map((b, i) => (
                  <div key={i} className="flex items-start gap-2.5 text-sm text-gray-700">
                    <CheckCircle2 className="w-4 h-4 text-[#00897B] flex-shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-teal-50 text-xs text-[#004B4F] mb-6">
                <span className="font-semibold">Tiempo promedio de sesión:</span>
                <span className="font-bold">{selectedService.duration}</span>
              </div>

              <div className="flex gap-3">
                <button
                  id="service-modal-booking-btn"
                  onClick={() => {
                    const svc = selectedService.title;
                    setSelectedService(null);
                    onSelectServiceForBooking(svc);
                  }}
                  className="flex-1 py-3 bg-[#00897B] hover:bg-[#007367] text-white font-semibold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Agendar esta especialidad</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
