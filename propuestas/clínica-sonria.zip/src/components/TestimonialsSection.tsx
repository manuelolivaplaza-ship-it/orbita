import React from 'react';
import { motion } from 'motion/react';
import { Star, Quote, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { TESTIMONIALS_DATA } from '../data/dentalData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonios" className="py-20 lg:py-28 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-50 text-[#00897B] text-xs font-bold uppercase tracking-wider mb-3">
            Opiniones de Pacientes
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#004B4F] tracking-tight">
            Historias reales de sonrisas recuperadas
          </h2>
          <p className="mt-4 text-base sm:text-lg text-gray-600">
            La confianza de nuestros pacientes en Santiago es nuestro mayor orgullo y compromiso de excelencia.
          </p>
        </div>

        {/* Testimonials 3 Columns Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((t, index) => (
            <motion.div
              key={t.id}
              id={`testimonial-card-${t.id}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              className="bg-[#F5F7F7] rounded-2xl p-7 sm:p-8 flex flex-col justify-between border border-teal-100/60 shadow-md hover:shadow-xl transition-all relative group"
            >
              <Quote className="w-10 h-10 text-teal-200/80 absolute top-6 right-6" />

              <div>
                {/* Stars Rating */}
                <div className="flex items-center gap-1 text-amber-400 mb-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                  <span className="ml-2 text-xs font-bold text-gray-700">5.0</span>
                </div>

                {/* Treatment Badge */}
                <div className="inline-block bg-teal-100 text-[#004B4F] text-xs font-semibold px-2.5 py-0.5 rounded-md mb-3">
                  Tratamiento: {t.treatment}
                </div>

                {/* Quote */}
                <p className="text-gray-700 text-sm sm:text-base leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Patient Info Footer */}
              <div className="pt-6 border-t border-gray-200/70 mt-6 flex items-center gap-3.5">
                <div
                  className={`w-11 h-11 rounded-full ${t.avatarBg} text-white font-bold flex items-center justify-center text-sm shadow-sm`}
                >
                  {t.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-gray-900 text-sm">{t.name}</h4>
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00897B]" />
                  </div>
                  <p className="text-xs text-gray-500">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Trust Banner Below */}
        <div className="mt-14 bg-gradient-to-r from-teal-50 via-white to-teal-50 rounded-2xl p-6 border border-teal-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#00897B] text-white flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-[#004B4F]">Compromiso Ético y Garantía Clínica</h4>
              <p className="text-xs text-gray-600">Presupuestos transparentes sin cobros sorpresa y seguimiento continuo.</p>
            </div>
          </div>
          <div className="text-xs font-semibold text-[#00897B]">
            Más de 5.000 pacientes atendidos con éxito
          </div>
        </div>

      </div>
    </section>
  );
};
