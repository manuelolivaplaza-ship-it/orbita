export interface DentalService {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  benefits: string[];
  duration: string;
  iconName: string;
  featured?: boolean;
  bgType?: 'solid-dark' | 'image' | 'light' | 'accent';
  imageUrl?: string;
  badge?: string;
}

export interface StatMetric {
  value: string;
  numericValue: number;
  suffix: string;
  label: string;
  subtext: string;
  iconName: string;
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  detail: string;
  iconName: string;
}

export interface BeforeAfterCase {
  id: string;
  title: string;
  treatment: string;
  duration: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  patientAge: string;
  highlights: string[];
}

export interface PatientTestimonial {
  id: string;
  name: string;
  role: string;
  rating: number;
  treatment: string;
  quote: string;
  date: string;
  avatarBg: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  price: string;
  period?: string;
  installments: string;
  isPopular?: boolean;
  features: string[];
  ctaText: string;
  badge?: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface AppointmentFormState {
  name: string;
  email: string;
  phone: string;
  specialty: string;
  preferredDate: string;
  preferredTime: string;
  notes: string;
}
